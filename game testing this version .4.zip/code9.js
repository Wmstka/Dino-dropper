gdjs.Level_327Code = {};
gdjs.Level_327Code.localVariables = [];
gdjs.Level_327Code.GDNewTextObjects1= [];
gdjs.Level_327Code.GDNewTextObjects2= [];
gdjs.Level_327Code.GDNewText2Objects1= [];
gdjs.Level_327Code.GDNewText2Objects2= [];
gdjs.Level_327Code.GDPlayer_9595currencyObjects1= [];
gdjs.Level_327Code.GDPlayer_9595currencyObjects2= [];
gdjs.Level_327Code.GDGreenLeaves2Objects1= [];
gdjs.Level_327Code.GDGreenLeaves2Objects2= [];
gdjs.Level_327Code.GDDinoDoux2Objects1= [];
gdjs.Level_327Code.GDDinoDoux2Objects2= [];
gdjs.Level_327Code.GDOrangeLeaves3Objects1= [];
gdjs.Level_327Code.GDOrangeLeaves3Objects2= [];
gdjs.Level_327Code.GDGreenBush7Objects1= [];
gdjs.Level_327Code.GDGreenBush7Objects2= [];
gdjs.Level_327Code.GDGreenBush8Objects1= [];
gdjs.Level_327Code.GDGreenBush8Objects2= [];
gdjs.Level_327Code.GDBlueSmallPlant2Objects1= [];
gdjs.Level_327Code.GDBlueSmallPlant2Objects2= [];
gdjs.Level_327Code.GDBlueFlower2Objects1= [];
gdjs.Level_327Code.GDBlueFlower2Objects2= [];
gdjs.Level_327Code.GDRock3Objects1= [];
gdjs.Level_327Code.GDRock3Objects2= [];
gdjs.Level_327Code.GDCircleObjects1= [];
gdjs.Level_327Code.GDCircleObjects2= [];
gdjs.Level_327Code.GDLineLightJoystickObjects1= [];
gdjs.Level_327Code.GDLineLightJoystickObjects2= [];


gdjs.Level_327Code.mapOfGDgdjs_9546Level_9595327Code_9546GDDinoDoux2Objects1Objects = Hashtable.newFrom({"DinoDoux2": gdjs.Level_327Code.GDDinoDoux2Objects1});
gdjs.Level_327Code.mapOfGDgdjs_9546Level_9595327Code_9546GDRock3Objects1Objects = Hashtable.newFrom({"Rock3": gdjs.Level_327Code.GDRock3Objects1});
gdjs.Level_327Code.mapOfGDgdjs_9546Level_9595327Code_9546GDDinoDoux2Objects1Objects = Hashtable.newFrom({"DinoDoux2": gdjs.Level_327Code.GDDinoDoux2Objects1});
gdjs.Level_327Code.mapOfGDgdjs_9546Level_9595327Code_9546GDBlueFlower2Objects1Objects = Hashtable.newFrom({"BlueFlower2": gdjs.Level_327Code.GDBlueFlower2Objects1});
gdjs.Level_327Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DinoDoux2"), gdjs.Level_327Code.GDDinoDoux2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Rock3"), gdjs.Level_327Code.GDRock3Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_327Code.mapOfGDgdjs_9546Level_9595327Code_9546GDDinoDoux2Objects1Objects, gdjs.Level_327Code.mapOfGDgdjs_9546Level_9595327Code_9546GDRock3Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level 7", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlueFlower2"), gdjs.Level_327Code.GDBlueFlower2Objects1);
gdjs.copyArray(runtimeScene.getObjects("DinoDoux2"), gdjs.Level_327Code.GDDinoDoux2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_327Code.mapOfGDgdjs_9546Level_9595327Code_9546GDDinoDoux2Objects1Objects, gdjs.Level_327Code.mapOfGDgdjs_9546Level_9595327Code_9546GDBlueFlower2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level 8", false);
}}

}


};

gdjs.Level_327Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level_327Code.GDNewTextObjects1.length = 0;
gdjs.Level_327Code.GDNewTextObjects2.length = 0;
gdjs.Level_327Code.GDNewText2Objects1.length = 0;
gdjs.Level_327Code.GDNewText2Objects2.length = 0;
gdjs.Level_327Code.GDPlayer_9595currencyObjects1.length = 0;
gdjs.Level_327Code.GDPlayer_9595currencyObjects2.length = 0;
gdjs.Level_327Code.GDGreenLeaves2Objects1.length = 0;
gdjs.Level_327Code.GDGreenLeaves2Objects2.length = 0;
gdjs.Level_327Code.GDDinoDoux2Objects1.length = 0;
gdjs.Level_327Code.GDDinoDoux2Objects2.length = 0;
gdjs.Level_327Code.GDOrangeLeaves3Objects1.length = 0;
gdjs.Level_327Code.GDOrangeLeaves3Objects2.length = 0;
gdjs.Level_327Code.GDGreenBush7Objects1.length = 0;
gdjs.Level_327Code.GDGreenBush7Objects2.length = 0;
gdjs.Level_327Code.GDGreenBush8Objects1.length = 0;
gdjs.Level_327Code.GDGreenBush8Objects2.length = 0;
gdjs.Level_327Code.GDBlueSmallPlant2Objects1.length = 0;
gdjs.Level_327Code.GDBlueSmallPlant2Objects2.length = 0;
gdjs.Level_327Code.GDBlueFlower2Objects1.length = 0;
gdjs.Level_327Code.GDBlueFlower2Objects2.length = 0;
gdjs.Level_327Code.GDRock3Objects1.length = 0;
gdjs.Level_327Code.GDRock3Objects2.length = 0;
gdjs.Level_327Code.GDCircleObjects1.length = 0;
gdjs.Level_327Code.GDCircleObjects2.length = 0;
gdjs.Level_327Code.GDLineLightJoystickObjects1.length = 0;
gdjs.Level_327Code.GDLineLightJoystickObjects2.length = 0;

gdjs.Level_327Code.eventsList0(runtimeScene);
gdjs.Level_327Code.GDNewTextObjects1.length = 0;
gdjs.Level_327Code.GDNewTextObjects2.length = 0;
gdjs.Level_327Code.GDNewText2Objects1.length = 0;
gdjs.Level_327Code.GDNewText2Objects2.length = 0;
gdjs.Level_327Code.GDPlayer_9595currencyObjects1.length = 0;
gdjs.Level_327Code.GDPlayer_9595currencyObjects2.length = 0;
gdjs.Level_327Code.GDGreenLeaves2Objects1.length = 0;
gdjs.Level_327Code.GDGreenLeaves2Objects2.length = 0;
gdjs.Level_327Code.GDDinoDoux2Objects1.length = 0;
gdjs.Level_327Code.GDDinoDoux2Objects2.length = 0;
gdjs.Level_327Code.GDOrangeLeaves3Objects1.length = 0;
gdjs.Level_327Code.GDOrangeLeaves3Objects2.length = 0;
gdjs.Level_327Code.GDGreenBush7Objects1.length = 0;
gdjs.Level_327Code.GDGreenBush7Objects2.length = 0;
gdjs.Level_327Code.GDGreenBush8Objects1.length = 0;
gdjs.Level_327Code.GDGreenBush8Objects2.length = 0;
gdjs.Level_327Code.GDBlueSmallPlant2Objects1.length = 0;
gdjs.Level_327Code.GDBlueSmallPlant2Objects2.length = 0;
gdjs.Level_327Code.GDBlueFlower2Objects1.length = 0;
gdjs.Level_327Code.GDBlueFlower2Objects2.length = 0;
gdjs.Level_327Code.GDRock3Objects1.length = 0;
gdjs.Level_327Code.GDRock3Objects2.length = 0;
gdjs.Level_327Code.GDCircleObjects1.length = 0;
gdjs.Level_327Code.GDCircleObjects2.length = 0;
gdjs.Level_327Code.GDLineLightJoystickObjects1.length = 0;
gdjs.Level_327Code.GDLineLightJoystickObjects2.length = 0;


return;

}

gdjs['Level_327Code'] = gdjs.Level_327Code;
