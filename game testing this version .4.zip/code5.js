gdjs.Level_324Code = {};
gdjs.Level_324Code.localVariables = [];
gdjs.Level_324Code.GDDinoDouxObjects1= [];
gdjs.Level_324Code.GDDinoDouxObjects2= [];
gdjs.Level_324Code.GDGreenLeaves2Objects1= [];
gdjs.Level_324Code.GDGreenLeaves2Objects2= [];
gdjs.Level_324Code.GDOrangeLeaves2Objects1= [];
gdjs.Level_324Code.GDOrangeLeaves2Objects2= [];
gdjs.Level_324Code.GDGreenBush5Objects1= [];
gdjs.Level_324Code.GDGreenBush5Objects2= [];
gdjs.Level_324Code.GDGreenBush6Objects1= [];
gdjs.Level_324Code.GDGreenBush6Objects2= [];
gdjs.Level_324Code.GDNewTextObjects1= [];
gdjs.Level_324Code.GDNewTextObjects2= [];
gdjs.Level_324Code.GDNewText2Objects1= [];
gdjs.Level_324Code.GDNewText2Objects2= [];
gdjs.Level_324Code.GDNewText3Objects1= [];
gdjs.Level_324Code.GDNewText3Objects2= [];
gdjs.Level_324Code.GDPlayer_9595currencyObjects1= [];
gdjs.Level_324Code.GDPlayer_9595currencyObjects2= [];
gdjs.Level_324Code.GDGreenLeaves2Objects1= [];
gdjs.Level_324Code.GDGreenLeaves2Objects2= [];
gdjs.Level_324Code.GDDinoDoux2Objects1= [];
gdjs.Level_324Code.GDDinoDoux2Objects2= [];
gdjs.Level_324Code.GDOrangeLeaves3Objects1= [];
gdjs.Level_324Code.GDOrangeLeaves3Objects2= [];
gdjs.Level_324Code.GDGreenBush7Objects1= [];
gdjs.Level_324Code.GDGreenBush7Objects2= [];
gdjs.Level_324Code.GDGreenBush8Objects1= [];
gdjs.Level_324Code.GDGreenBush8Objects2= [];
gdjs.Level_324Code.GDBlueSmallPlant2Objects1= [];
gdjs.Level_324Code.GDBlueSmallPlant2Objects2= [];
gdjs.Level_324Code.GDBlueFlower2Objects1= [];
gdjs.Level_324Code.GDBlueFlower2Objects2= [];
gdjs.Level_324Code.GDRock3Objects1= [];
gdjs.Level_324Code.GDRock3Objects2= [];
gdjs.Level_324Code.GDCircleObjects1= [];
gdjs.Level_324Code.GDCircleObjects2= [];
gdjs.Level_324Code.GDLineLightJoystickObjects1= [];
gdjs.Level_324Code.GDLineLightJoystickObjects2= [];


gdjs.Level_324Code.mapOfGDgdjs_9546Level_9595324Code_9546GDDinoDouxObjects1Objects = Hashtable.newFrom({"DinoDoux": gdjs.Level_324Code.GDDinoDouxObjects1});
gdjs.Level_324Code.mapOfGDgdjs_9546Level_9595324Code_9546GDGreenBush5Objects1Objects = Hashtable.newFrom({"GreenBush5": gdjs.Level_324Code.GDGreenBush5Objects1});
gdjs.Level_324Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DinoDoux"), gdjs.Level_324Code.GDDinoDouxObjects1);
gdjs.copyArray(runtimeScene.getObjects("GreenBush5"), gdjs.Level_324Code.GDGreenBush5Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_324Code.mapOfGDgdjs_9546Level_9595324Code_9546GDDinoDouxObjects1Objects, gdjs.Level_324Code.mapOfGDgdjs_9546Level_9595324Code_9546GDGreenBush5Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level 5", false);
}}

}


};

gdjs.Level_324Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level_324Code.GDDinoDouxObjects1.length = 0;
gdjs.Level_324Code.GDDinoDouxObjects2.length = 0;
gdjs.Level_324Code.GDGreenLeaves2Objects1.length = 0;
gdjs.Level_324Code.GDGreenLeaves2Objects2.length = 0;
gdjs.Level_324Code.GDOrangeLeaves2Objects1.length = 0;
gdjs.Level_324Code.GDOrangeLeaves2Objects2.length = 0;
gdjs.Level_324Code.GDGreenBush5Objects1.length = 0;
gdjs.Level_324Code.GDGreenBush5Objects2.length = 0;
gdjs.Level_324Code.GDGreenBush6Objects1.length = 0;
gdjs.Level_324Code.GDGreenBush6Objects2.length = 0;
gdjs.Level_324Code.GDNewTextObjects1.length = 0;
gdjs.Level_324Code.GDNewTextObjects2.length = 0;
gdjs.Level_324Code.GDNewText2Objects1.length = 0;
gdjs.Level_324Code.GDNewText2Objects2.length = 0;
gdjs.Level_324Code.GDNewText3Objects1.length = 0;
gdjs.Level_324Code.GDNewText3Objects2.length = 0;
gdjs.Level_324Code.GDPlayer_9595currencyObjects1.length = 0;
gdjs.Level_324Code.GDPlayer_9595currencyObjects2.length = 0;
gdjs.Level_324Code.GDGreenLeaves2Objects1.length = 0;
gdjs.Level_324Code.GDGreenLeaves2Objects2.length = 0;
gdjs.Level_324Code.GDDinoDoux2Objects1.length = 0;
gdjs.Level_324Code.GDDinoDoux2Objects2.length = 0;
gdjs.Level_324Code.GDOrangeLeaves3Objects1.length = 0;
gdjs.Level_324Code.GDOrangeLeaves3Objects2.length = 0;
gdjs.Level_324Code.GDGreenBush7Objects1.length = 0;
gdjs.Level_324Code.GDGreenBush7Objects2.length = 0;
gdjs.Level_324Code.GDGreenBush8Objects1.length = 0;
gdjs.Level_324Code.GDGreenBush8Objects2.length = 0;
gdjs.Level_324Code.GDBlueSmallPlant2Objects1.length = 0;
gdjs.Level_324Code.GDBlueSmallPlant2Objects2.length = 0;
gdjs.Level_324Code.GDBlueFlower2Objects1.length = 0;
gdjs.Level_324Code.GDBlueFlower2Objects2.length = 0;
gdjs.Level_324Code.GDRock3Objects1.length = 0;
gdjs.Level_324Code.GDRock3Objects2.length = 0;
gdjs.Level_324Code.GDCircleObjects1.length = 0;
gdjs.Level_324Code.GDCircleObjects2.length = 0;
gdjs.Level_324Code.GDLineLightJoystickObjects1.length = 0;
gdjs.Level_324Code.GDLineLightJoystickObjects2.length = 0;

gdjs.Level_324Code.eventsList0(runtimeScene);
gdjs.Level_324Code.GDDinoDouxObjects1.length = 0;
gdjs.Level_324Code.GDDinoDouxObjects2.length = 0;
gdjs.Level_324Code.GDGreenLeaves2Objects1.length = 0;
gdjs.Level_324Code.GDGreenLeaves2Objects2.length = 0;
gdjs.Level_324Code.GDOrangeLeaves2Objects1.length = 0;
gdjs.Level_324Code.GDOrangeLeaves2Objects2.length = 0;
gdjs.Level_324Code.GDGreenBush5Objects1.length = 0;
gdjs.Level_324Code.GDGreenBush5Objects2.length = 0;
gdjs.Level_324Code.GDGreenBush6Objects1.length = 0;
gdjs.Level_324Code.GDGreenBush6Objects2.length = 0;
gdjs.Level_324Code.GDNewTextObjects1.length = 0;
gdjs.Level_324Code.GDNewTextObjects2.length = 0;
gdjs.Level_324Code.GDNewText2Objects1.length = 0;
gdjs.Level_324Code.GDNewText2Objects2.length = 0;
gdjs.Level_324Code.GDNewText3Objects1.length = 0;
gdjs.Level_324Code.GDNewText3Objects2.length = 0;
gdjs.Level_324Code.GDPlayer_9595currencyObjects1.length = 0;
gdjs.Level_324Code.GDPlayer_9595currencyObjects2.length = 0;
gdjs.Level_324Code.GDGreenLeaves2Objects1.length = 0;
gdjs.Level_324Code.GDGreenLeaves2Objects2.length = 0;
gdjs.Level_324Code.GDDinoDoux2Objects1.length = 0;
gdjs.Level_324Code.GDDinoDoux2Objects2.length = 0;
gdjs.Level_324Code.GDOrangeLeaves3Objects1.length = 0;
gdjs.Level_324Code.GDOrangeLeaves3Objects2.length = 0;
gdjs.Level_324Code.GDGreenBush7Objects1.length = 0;
gdjs.Level_324Code.GDGreenBush7Objects2.length = 0;
gdjs.Level_324Code.GDGreenBush8Objects1.length = 0;
gdjs.Level_324Code.GDGreenBush8Objects2.length = 0;
gdjs.Level_324Code.GDBlueSmallPlant2Objects1.length = 0;
gdjs.Level_324Code.GDBlueSmallPlant2Objects2.length = 0;
gdjs.Level_324Code.GDBlueFlower2Objects1.length = 0;
gdjs.Level_324Code.GDBlueFlower2Objects2.length = 0;
gdjs.Level_324Code.GDRock3Objects1.length = 0;
gdjs.Level_324Code.GDRock3Objects2.length = 0;
gdjs.Level_324Code.GDCircleObjects1.length = 0;
gdjs.Level_324Code.GDCircleObjects2.length = 0;
gdjs.Level_324Code.GDLineLightJoystickObjects1.length = 0;
gdjs.Level_324Code.GDLineLightJoystickObjects2.length = 0;


return;

}

gdjs['Level_324Code'] = gdjs.Level_324Code;
