gdjs.Main_32menuCode = {};
gdjs.Main_32menuCode.localVariables = [];
gdjs.Main_32menuCode.GDNewTextObjects1= [];
gdjs.Main_32menuCode.GDNewTextObjects2= [];
gdjs.Main_32menuCode.GDBlackSquareDecoratedButtonObjects1= [];
gdjs.Main_32menuCode.GDBlackSquareDecoratedButtonObjects2= [];
gdjs.Main_32menuCode.GDBlackDecoratedButtonObjects1= [];
gdjs.Main_32menuCode.GDBlackDecoratedButtonObjects2= [];
gdjs.Main_32menuCode.GDBlueButtonObjects1= [];
gdjs.Main_32menuCode.GDBlueButtonObjects2= [];
gdjs.Main_32menuCode.GDBrownButtonWithShadowObjects1= [];
gdjs.Main_32menuCode.GDBrownButtonWithShadowObjects2= [];
gdjs.Main_32menuCode.GDFloatingOutButtonDarkBlueObjects1= [];
gdjs.Main_32menuCode.GDFloatingOutButtonDarkBlueObjects2= [];
gdjs.Main_32menuCode.GDBlueButtonWithShadowObjects1= [];
gdjs.Main_32menuCode.GDBlueButtonWithShadowObjects2= [];
gdjs.Main_32menuCode.GDGreenButtonWithShadowObjects1= [];
gdjs.Main_32menuCode.GDGreenButtonWithShadowObjects2= [];
gdjs.Main_32menuCode.GDGreenButtonObjects1= [];
gdjs.Main_32menuCode.GDGreenButtonObjects2= [];
gdjs.Main_32menuCode.GDGreenButtonWithStoneFrameObjects1= [];
gdjs.Main_32menuCode.GDGreenButtonWithStoneFrameObjects2= [];
gdjs.Main_32menuCode.GDGreyButtonObjects1= [];
gdjs.Main_32menuCode.GDGreyButtonObjects2= [];
gdjs.Main_32menuCode.GDGreyButtonWithShadowObjects1= [];
gdjs.Main_32menuCode.GDGreyButtonWithShadowObjects2= [];
gdjs.Main_32menuCode.GDMedievalButtonBrownObjects1= [];
gdjs.Main_32menuCode.GDMedievalButtonBrownObjects2= [];
gdjs.Main_32menuCode.GDPurpleButtonWithShadowObjects1= [];
gdjs.Main_32menuCode.GDPurpleButtonWithShadowObjects2= [];
gdjs.Main_32menuCode.GDOrangeBubbleButtonObjects1= [];
gdjs.Main_32menuCode.GDOrangeBubbleButtonObjects2= [];
gdjs.Main_32menuCode.GDOrangeButtonWithStoneFrameObjects1= [];
gdjs.Main_32menuCode.GDOrangeButtonWithStoneFrameObjects2= [];
gdjs.Main_32menuCode.GDOnScreenControlsButtonObjects1= [];
gdjs.Main_32menuCode.GDOnScreenControlsButtonObjects2= [];
gdjs.Main_32menuCode.GDMedievalButtonBeigeObjects1= [];
gdjs.Main_32menuCode.GDMedievalButtonBeigeObjects2= [];
gdjs.Main_32menuCode.GDRedButtonWithGoldFrameObjects1= [];
gdjs.Main_32menuCode.GDRedButtonWithGoldFrameObjects2= [];
gdjs.Main_32menuCode.GDPurpleButtonWithStoneFrameObjects1= [];
gdjs.Main_32menuCode.GDPurpleButtonWithStoneFrameObjects2= [];
gdjs.Main_32menuCode.GDRedButtonWithShadowObjects1= [];
gdjs.Main_32menuCode.GDRedButtonWithShadowObjects2= [];
gdjs.Main_32menuCode.GDRedButtonWithStoneFrameObjects1= [];
gdjs.Main_32menuCode.GDRedButtonWithStoneFrameObjects2= [];
gdjs.Main_32menuCode.GDRedButtonWithMetalFrameObjects1= [];
gdjs.Main_32menuCode.GDRedButtonWithMetalFrameObjects2= [];
gdjs.Main_32menuCode.GDRedButtonObjects1= [];
gdjs.Main_32menuCode.GDRedButtonObjects2= [];
gdjs.Main_32menuCode.GDTransparentButtonWithWhiteBlueBorderObjects1= [];
gdjs.Main_32menuCode.GDTransparentButtonWithWhiteBlueBorderObjects2= [];
gdjs.Main_32menuCode.GDWhiteDecoratedButtonObjects1= [];
gdjs.Main_32menuCode.GDWhiteDecoratedButtonObjects2= [];
gdjs.Main_32menuCode.GDWhiteSleekButtonObjects1= [];
gdjs.Main_32menuCode.GDWhiteSleekButtonObjects2= [];
gdjs.Main_32menuCode.GDTransparentButtonWithWhiteYellowBorderObjects1= [];
gdjs.Main_32menuCode.GDTransparentButtonWithWhiteYellowBorderObjects2= [];
gdjs.Main_32menuCode.GDWhiteSquareDecoratedButtonObjects1= [];
gdjs.Main_32menuCode.GDWhiteSquareDecoratedButtonObjects2= [];
gdjs.Main_32menuCode.GDYellowButtonObjects1= [];
gdjs.Main_32menuCode.GDYellowButtonObjects2= [];
gdjs.Main_32menuCode.GDYellowJellyButtonObjects1= [];
gdjs.Main_32menuCode.GDYellowJellyButtonObjects2= [];
gdjs.Main_32menuCode.GDNewPanelSpriteObjects1= [];
gdjs.Main_32menuCode.GDNewPanelSpriteObjects2= [];
gdjs.Main_32menuCode.GDNewText2Objects1= [];
gdjs.Main_32menuCode.GDNewText2Objects2= [];
gdjs.Main_32menuCode.GDNewVideoObjects1= [];
gdjs.Main_32menuCode.GDNewVideoObjects2= [];
gdjs.Main_32menuCode.GDshopObjects1= [];
gdjs.Main_32menuCode.GDshopObjects2= [];
gdjs.Main_32menuCode.GDPlayer_9595currencyObjects1= [];
gdjs.Main_32menuCode.GDPlayer_9595currencyObjects2= [];
gdjs.Main_32menuCode.GDGreenLeaves2Objects1= [];
gdjs.Main_32menuCode.GDGreenLeaves2Objects2= [];
gdjs.Main_32menuCode.GDDinoDoux2Objects1= [];
gdjs.Main_32menuCode.GDDinoDoux2Objects2= [];
gdjs.Main_32menuCode.GDOrangeLeaves3Objects1= [];
gdjs.Main_32menuCode.GDOrangeLeaves3Objects2= [];
gdjs.Main_32menuCode.GDGreenBush7Objects1= [];
gdjs.Main_32menuCode.GDGreenBush7Objects2= [];
gdjs.Main_32menuCode.GDGreenBush8Objects1= [];
gdjs.Main_32menuCode.GDGreenBush8Objects2= [];
gdjs.Main_32menuCode.GDBlueSmallPlant2Objects1= [];
gdjs.Main_32menuCode.GDBlueSmallPlant2Objects2= [];
gdjs.Main_32menuCode.GDBlueFlower2Objects1= [];
gdjs.Main_32menuCode.GDBlueFlower2Objects2= [];
gdjs.Main_32menuCode.GDRock3Objects1= [];
gdjs.Main_32menuCode.GDRock3Objects2= [];
gdjs.Main_32menuCode.GDCircleObjects1= [];
gdjs.Main_32menuCode.GDCircleObjects2= [];
gdjs.Main_32menuCode.GDLineLightJoystickObjects1= [];
gdjs.Main_32menuCode.GDLineLightJoystickObjects2= [];


gdjs.Main_32menuCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("YellowButton"), gdjs.Main_32menuCode.GDYellowButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32menuCode.GDYellowButtonObjects1.length;i<l;++i) {
    if ( gdjs.Main_32menuCode.GDYellowButtonObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32menuCode.GDYellowButtonObjects1[k] = gdjs.Main_32menuCode.GDYellowButtonObjects1[i];
        ++k;
    }
}
gdjs.Main_32menuCode.GDYellowButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "tut/ Level 1", false);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Gamepads__C_Any_Button_pressed.func(runtimeScene, 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "Over_the_Horizon.mp3", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("shop"), gdjs.Main_32menuCode.GDshopObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32menuCode.GDshopObjects1.length;i<l;++i) {
    if ( gdjs.Main_32menuCode.GDshopObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32menuCode.GDshopObjects1[k] = gdjs.Main_32menuCode.GDshopObjects1[i];
        ++k;
    }
}
gdjs.Main_32menuCode.GDshopObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "shop type shh", false);
}}

}


};

gdjs.Main_32menuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Main_32menuCode.GDNewTextObjects1.length = 0;
gdjs.Main_32menuCode.GDNewTextObjects2.length = 0;
gdjs.Main_32menuCode.GDBlackSquareDecoratedButtonObjects1.length = 0;
gdjs.Main_32menuCode.GDBlackSquareDecoratedButtonObjects2.length = 0;
gdjs.Main_32menuCode.GDBlackDecoratedButtonObjects1.length = 0;
gdjs.Main_32menuCode.GDBlackDecoratedButtonObjects2.length = 0;
gdjs.Main_32menuCode.GDBlueButtonObjects1.length = 0;
gdjs.Main_32menuCode.GDBlueButtonObjects2.length = 0;
gdjs.Main_32menuCode.GDBrownButtonWithShadowObjects1.length = 0;
gdjs.Main_32menuCode.GDBrownButtonWithShadowObjects2.length = 0;
gdjs.Main_32menuCode.GDFloatingOutButtonDarkBlueObjects1.length = 0;
gdjs.Main_32menuCode.GDFloatingOutButtonDarkBlueObjects2.length = 0;
gdjs.Main_32menuCode.GDBlueButtonWithShadowObjects1.length = 0;
gdjs.Main_32menuCode.GDBlueButtonWithShadowObjects2.length = 0;
gdjs.Main_32menuCode.GDGreenButtonWithShadowObjects1.length = 0;
gdjs.Main_32menuCode.GDGreenButtonWithShadowObjects2.length = 0;
gdjs.Main_32menuCode.GDGreenButtonObjects1.length = 0;
gdjs.Main_32menuCode.GDGreenButtonObjects2.length = 0;
gdjs.Main_32menuCode.GDGreenButtonWithStoneFrameObjects1.length = 0;
gdjs.Main_32menuCode.GDGreenButtonWithStoneFrameObjects2.length = 0;
gdjs.Main_32menuCode.GDGreyButtonObjects1.length = 0;
gdjs.Main_32menuCode.GDGreyButtonObjects2.length = 0;
gdjs.Main_32menuCode.GDGreyButtonWithShadowObjects1.length = 0;
gdjs.Main_32menuCode.GDGreyButtonWithShadowObjects2.length = 0;
gdjs.Main_32menuCode.GDMedievalButtonBrownObjects1.length = 0;
gdjs.Main_32menuCode.GDMedievalButtonBrownObjects2.length = 0;
gdjs.Main_32menuCode.GDPurpleButtonWithShadowObjects1.length = 0;
gdjs.Main_32menuCode.GDPurpleButtonWithShadowObjects2.length = 0;
gdjs.Main_32menuCode.GDOrangeBubbleButtonObjects1.length = 0;
gdjs.Main_32menuCode.GDOrangeBubbleButtonObjects2.length = 0;
gdjs.Main_32menuCode.GDOrangeButtonWithStoneFrameObjects1.length = 0;
gdjs.Main_32menuCode.GDOrangeButtonWithStoneFrameObjects2.length = 0;
gdjs.Main_32menuCode.GDOnScreenControlsButtonObjects1.length = 0;
gdjs.Main_32menuCode.GDOnScreenControlsButtonObjects2.length = 0;
gdjs.Main_32menuCode.GDMedievalButtonBeigeObjects1.length = 0;
gdjs.Main_32menuCode.GDMedievalButtonBeigeObjects2.length = 0;
gdjs.Main_32menuCode.GDRedButtonWithGoldFrameObjects1.length = 0;
gdjs.Main_32menuCode.GDRedButtonWithGoldFrameObjects2.length = 0;
gdjs.Main_32menuCode.GDPurpleButtonWithStoneFrameObjects1.length = 0;
gdjs.Main_32menuCode.GDPurpleButtonWithStoneFrameObjects2.length = 0;
gdjs.Main_32menuCode.GDRedButtonWithShadowObjects1.length = 0;
gdjs.Main_32menuCode.GDRedButtonWithShadowObjects2.length = 0;
gdjs.Main_32menuCode.GDRedButtonWithStoneFrameObjects1.length = 0;
gdjs.Main_32menuCode.GDRedButtonWithStoneFrameObjects2.length = 0;
gdjs.Main_32menuCode.GDRedButtonWithMetalFrameObjects1.length = 0;
gdjs.Main_32menuCode.GDRedButtonWithMetalFrameObjects2.length = 0;
gdjs.Main_32menuCode.GDRedButtonObjects1.length = 0;
gdjs.Main_32menuCode.GDRedButtonObjects2.length = 0;
gdjs.Main_32menuCode.GDTransparentButtonWithWhiteBlueBorderObjects1.length = 0;
gdjs.Main_32menuCode.GDTransparentButtonWithWhiteBlueBorderObjects2.length = 0;
gdjs.Main_32menuCode.GDWhiteDecoratedButtonObjects1.length = 0;
gdjs.Main_32menuCode.GDWhiteDecoratedButtonObjects2.length = 0;
gdjs.Main_32menuCode.GDWhiteSleekButtonObjects1.length = 0;
gdjs.Main_32menuCode.GDWhiteSleekButtonObjects2.length = 0;
gdjs.Main_32menuCode.GDTransparentButtonWithWhiteYellowBorderObjects1.length = 0;
gdjs.Main_32menuCode.GDTransparentButtonWithWhiteYellowBorderObjects2.length = 0;
gdjs.Main_32menuCode.GDWhiteSquareDecoratedButtonObjects1.length = 0;
gdjs.Main_32menuCode.GDWhiteSquareDecoratedButtonObjects2.length = 0;
gdjs.Main_32menuCode.GDYellowButtonObjects1.length = 0;
gdjs.Main_32menuCode.GDYellowButtonObjects2.length = 0;
gdjs.Main_32menuCode.GDYellowJellyButtonObjects1.length = 0;
gdjs.Main_32menuCode.GDYellowJellyButtonObjects2.length = 0;
gdjs.Main_32menuCode.GDNewPanelSpriteObjects1.length = 0;
gdjs.Main_32menuCode.GDNewPanelSpriteObjects2.length = 0;
gdjs.Main_32menuCode.GDNewText2Objects1.length = 0;
gdjs.Main_32menuCode.GDNewText2Objects2.length = 0;
gdjs.Main_32menuCode.GDNewVideoObjects1.length = 0;
gdjs.Main_32menuCode.GDNewVideoObjects2.length = 0;
gdjs.Main_32menuCode.GDshopObjects1.length = 0;
gdjs.Main_32menuCode.GDshopObjects2.length = 0;
gdjs.Main_32menuCode.GDPlayer_9595currencyObjects1.length = 0;
gdjs.Main_32menuCode.GDPlayer_9595currencyObjects2.length = 0;
gdjs.Main_32menuCode.GDGreenLeaves2Objects1.length = 0;
gdjs.Main_32menuCode.GDGreenLeaves2Objects2.length = 0;
gdjs.Main_32menuCode.GDDinoDoux2Objects1.length = 0;
gdjs.Main_32menuCode.GDDinoDoux2Objects2.length = 0;
gdjs.Main_32menuCode.GDOrangeLeaves3Objects1.length = 0;
gdjs.Main_32menuCode.GDOrangeLeaves3Objects2.length = 0;
gdjs.Main_32menuCode.GDGreenBush7Objects1.length = 0;
gdjs.Main_32menuCode.GDGreenBush7Objects2.length = 0;
gdjs.Main_32menuCode.GDGreenBush8Objects1.length = 0;
gdjs.Main_32menuCode.GDGreenBush8Objects2.length = 0;
gdjs.Main_32menuCode.GDBlueSmallPlant2Objects1.length = 0;
gdjs.Main_32menuCode.GDBlueSmallPlant2Objects2.length = 0;
gdjs.Main_32menuCode.GDBlueFlower2Objects1.length = 0;
gdjs.Main_32menuCode.GDBlueFlower2Objects2.length = 0;
gdjs.Main_32menuCode.GDRock3Objects1.length = 0;
gdjs.Main_32menuCode.GDRock3Objects2.length = 0;
gdjs.Main_32menuCode.GDCircleObjects1.length = 0;
gdjs.Main_32menuCode.GDCircleObjects2.length = 0;
gdjs.Main_32menuCode.GDLineLightJoystickObjects1.length = 0;
gdjs.Main_32menuCode.GDLineLightJoystickObjects2.length = 0;

gdjs.Main_32menuCode.eventsList0(runtimeScene);
gdjs.Main_32menuCode.GDNewTextObjects1.length = 0;
gdjs.Main_32menuCode.GDNewTextObjects2.length = 0;
gdjs.Main_32menuCode.GDBlackSquareDecoratedButtonObjects1.length = 0;
gdjs.Main_32menuCode.GDBlackSquareDecoratedButtonObjects2.length = 0;
gdjs.Main_32menuCode.GDBlackDecoratedButtonObjects1.length = 0;
gdjs.Main_32menuCode.GDBlackDecoratedButtonObjects2.length = 0;
gdjs.Main_32menuCode.GDBlueButtonObjects1.length = 0;
gdjs.Main_32menuCode.GDBlueButtonObjects2.length = 0;
gdjs.Main_32menuCode.GDBrownButtonWithShadowObjects1.length = 0;
gdjs.Main_32menuCode.GDBrownButtonWithShadowObjects2.length = 0;
gdjs.Main_32menuCode.GDFloatingOutButtonDarkBlueObjects1.length = 0;
gdjs.Main_32menuCode.GDFloatingOutButtonDarkBlueObjects2.length = 0;
gdjs.Main_32menuCode.GDBlueButtonWithShadowObjects1.length = 0;
gdjs.Main_32menuCode.GDBlueButtonWithShadowObjects2.length = 0;
gdjs.Main_32menuCode.GDGreenButtonWithShadowObjects1.length = 0;
gdjs.Main_32menuCode.GDGreenButtonWithShadowObjects2.length = 0;
gdjs.Main_32menuCode.GDGreenButtonObjects1.length = 0;
gdjs.Main_32menuCode.GDGreenButtonObjects2.length = 0;
gdjs.Main_32menuCode.GDGreenButtonWithStoneFrameObjects1.length = 0;
gdjs.Main_32menuCode.GDGreenButtonWithStoneFrameObjects2.length = 0;
gdjs.Main_32menuCode.GDGreyButtonObjects1.length = 0;
gdjs.Main_32menuCode.GDGreyButtonObjects2.length = 0;
gdjs.Main_32menuCode.GDGreyButtonWithShadowObjects1.length = 0;
gdjs.Main_32menuCode.GDGreyButtonWithShadowObjects2.length = 0;
gdjs.Main_32menuCode.GDMedievalButtonBrownObjects1.length = 0;
gdjs.Main_32menuCode.GDMedievalButtonBrownObjects2.length = 0;
gdjs.Main_32menuCode.GDPurpleButtonWithShadowObjects1.length = 0;
gdjs.Main_32menuCode.GDPurpleButtonWithShadowObjects2.length = 0;
gdjs.Main_32menuCode.GDOrangeBubbleButtonObjects1.length = 0;
gdjs.Main_32menuCode.GDOrangeBubbleButtonObjects2.length = 0;
gdjs.Main_32menuCode.GDOrangeButtonWithStoneFrameObjects1.length = 0;
gdjs.Main_32menuCode.GDOrangeButtonWithStoneFrameObjects2.length = 0;
gdjs.Main_32menuCode.GDOnScreenControlsButtonObjects1.length = 0;
gdjs.Main_32menuCode.GDOnScreenControlsButtonObjects2.length = 0;
gdjs.Main_32menuCode.GDMedievalButtonBeigeObjects1.length = 0;
gdjs.Main_32menuCode.GDMedievalButtonBeigeObjects2.length = 0;
gdjs.Main_32menuCode.GDRedButtonWithGoldFrameObjects1.length = 0;
gdjs.Main_32menuCode.GDRedButtonWithGoldFrameObjects2.length = 0;
gdjs.Main_32menuCode.GDPurpleButtonWithStoneFrameObjects1.length = 0;
gdjs.Main_32menuCode.GDPurpleButtonWithStoneFrameObjects2.length = 0;
gdjs.Main_32menuCode.GDRedButtonWithShadowObjects1.length = 0;
gdjs.Main_32menuCode.GDRedButtonWithShadowObjects2.length = 0;
gdjs.Main_32menuCode.GDRedButtonWithStoneFrameObjects1.length = 0;
gdjs.Main_32menuCode.GDRedButtonWithStoneFrameObjects2.length = 0;
gdjs.Main_32menuCode.GDRedButtonWithMetalFrameObjects1.length = 0;
gdjs.Main_32menuCode.GDRedButtonWithMetalFrameObjects2.length = 0;
gdjs.Main_32menuCode.GDRedButtonObjects1.length = 0;
gdjs.Main_32menuCode.GDRedButtonObjects2.length = 0;
gdjs.Main_32menuCode.GDTransparentButtonWithWhiteBlueBorderObjects1.length = 0;
gdjs.Main_32menuCode.GDTransparentButtonWithWhiteBlueBorderObjects2.length = 0;
gdjs.Main_32menuCode.GDWhiteDecoratedButtonObjects1.length = 0;
gdjs.Main_32menuCode.GDWhiteDecoratedButtonObjects2.length = 0;
gdjs.Main_32menuCode.GDWhiteSleekButtonObjects1.length = 0;
gdjs.Main_32menuCode.GDWhiteSleekButtonObjects2.length = 0;
gdjs.Main_32menuCode.GDTransparentButtonWithWhiteYellowBorderObjects1.length = 0;
gdjs.Main_32menuCode.GDTransparentButtonWithWhiteYellowBorderObjects2.length = 0;
gdjs.Main_32menuCode.GDWhiteSquareDecoratedButtonObjects1.length = 0;
gdjs.Main_32menuCode.GDWhiteSquareDecoratedButtonObjects2.length = 0;
gdjs.Main_32menuCode.GDYellowButtonObjects1.length = 0;
gdjs.Main_32menuCode.GDYellowButtonObjects2.length = 0;
gdjs.Main_32menuCode.GDYellowJellyButtonObjects1.length = 0;
gdjs.Main_32menuCode.GDYellowJellyButtonObjects2.length = 0;
gdjs.Main_32menuCode.GDNewPanelSpriteObjects1.length = 0;
gdjs.Main_32menuCode.GDNewPanelSpriteObjects2.length = 0;
gdjs.Main_32menuCode.GDNewText2Objects1.length = 0;
gdjs.Main_32menuCode.GDNewText2Objects2.length = 0;
gdjs.Main_32menuCode.GDNewVideoObjects1.length = 0;
gdjs.Main_32menuCode.GDNewVideoObjects2.length = 0;
gdjs.Main_32menuCode.GDshopObjects1.length = 0;
gdjs.Main_32menuCode.GDshopObjects2.length = 0;
gdjs.Main_32menuCode.GDPlayer_9595currencyObjects1.length = 0;
gdjs.Main_32menuCode.GDPlayer_9595currencyObjects2.length = 0;
gdjs.Main_32menuCode.GDGreenLeaves2Objects1.length = 0;
gdjs.Main_32menuCode.GDGreenLeaves2Objects2.length = 0;
gdjs.Main_32menuCode.GDDinoDoux2Objects1.length = 0;
gdjs.Main_32menuCode.GDDinoDoux2Objects2.length = 0;
gdjs.Main_32menuCode.GDOrangeLeaves3Objects1.length = 0;
gdjs.Main_32menuCode.GDOrangeLeaves3Objects2.length = 0;
gdjs.Main_32menuCode.GDGreenBush7Objects1.length = 0;
gdjs.Main_32menuCode.GDGreenBush7Objects2.length = 0;
gdjs.Main_32menuCode.GDGreenBush8Objects1.length = 0;
gdjs.Main_32menuCode.GDGreenBush8Objects2.length = 0;
gdjs.Main_32menuCode.GDBlueSmallPlant2Objects1.length = 0;
gdjs.Main_32menuCode.GDBlueSmallPlant2Objects2.length = 0;
gdjs.Main_32menuCode.GDBlueFlower2Objects1.length = 0;
gdjs.Main_32menuCode.GDBlueFlower2Objects2.length = 0;
gdjs.Main_32menuCode.GDRock3Objects1.length = 0;
gdjs.Main_32menuCode.GDRock3Objects2.length = 0;
gdjs.Main_32menuCode.GDCircleObjects1.length = 0;
gdjs.Main_32menuCode.GDCircleObjects2.length = 0;
gdjs.Main_32menuCode.GDLineLightJoystickObjects1.length = 0;
gdjs.Main_32menuCode.GDLineLightJoystickObjects2.length = 0;


return;

}

gdjs['Main_32menuCode'] = gdjs.Main_32menuCode;
