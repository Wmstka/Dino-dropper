gdjs.Level_325Code = {};
gdjs.Level_325Code.localVariables = [];
gdjs.Level_325Code.GDGreenLeaves2Objects1= [];
gdjs.Level_325Code.GDGreenLeaves2Objects2= [];
gdjs.Level_325Code.GDDinoDouxObjects1= [];
gdjs.Level_325Code.GDDinoDouxObjects2= [];
gdjs.Level_325Code.GDNewTextObjects1= [];
gdjs.Level_325Code.GDNewTextObjects2= [];
gdjs.Level_325Code.GDOrangeLeaves2Objects1= [];
gdjs.Level_325Code.GDOrangeLeaves2Objects2= [];
gdjs.Level_325Code.GDGreenBush5Objects1= [];
gdjs.Level_325Code.GDGreenBush5Objects2= [];
gdjs.Level_325Code.GDGreenBush6Objects1= [];
gdjs.Level_325Code.GDGreenBush6Objects2= [];
gdjs.Level_325Code.GDBlueSmallPlantObjects1= [];
gdjs.Level_325Code.GDBlueSmallPlantObjects2= [];
gdjs.Level_325Code.GDNewText2Objects1= [];
gdjs.Level_325Code.GDNewText2Objects2= [];
gdjs.Level_325Code.GDBlueFlowerObjects1= [];
gdjs.Level_325Code.GDBlueFlowerObjects2= [];
gdjs.Level_325Code.GDNewText3Objects1= [];
gdjs.Level_325Code.GDNewText3Objects2= [];
gdjs.Level_325Code.GDRock2Objects1= [];
gdjs.Level_325Code.GDRock2Objects2= [];
gdjs.Level_325Code.GDPlayer_9595currencyObjects1= [];
gdjs.Level_325Code.GDPlayer_9595currencyObjects2= [];
gdjs.Level_325Code.GDGreenLeaves2Objects1= [];
gdjs.Level_325Code.GDGreenLeaves2Objects2= [];
gdjs.Level_325Code.GDDinoDoux2Objects1= [];
gdjs.Level_325Code.GDDinoDoux2Objects2= [];
gdjs.Level_325Code.GDOrangeLeaves3Objects1= [];
gdjs.Level_325Code.GDOrangeLeaves3Objects2= [];
gdjs.Level_325Code.GDGreenBush7Objects1= [];
gdjs.Level_325Code.GDGreenBush7Objects2= [];
gdjs.Level_325Code.GDGreenBush8Objects1= [];
gdjs.Level_325Code.GDGreenBush8Objects2= [];
gdjs.Level_325Code.GDBlueSmallPlant2Objects1= [];
gdjs.Level_325Code.GDBlueSmallPlant2Objects2= [];
gdjs.Level_325Code.GDBlueFlower2Objects1= [];
gdjs.Level_325Code.GDBlueFlower2Objects2= [];
gdjs.Level_325Code.GDRock3Objects1= [];
gdjs.Level_325Code.GDRock3Objects2= [];
gdjs.Level_325Code.GDCircleObjects1= [];
gdjs.Level_325Code.GDCircleObjects2= [];
gdjs.Level_325Code.GDLineLightJoystickObjects1= [];
gdjs.Level_325Code.GDLineLightJoystickObjects2= [];


gdjs.Level_325Code.mapOfGDgdjs_9546Level_9595325Code_9546GDDinoDouxObjects1Objects = Hashtable.newFrom({"DinoDoux": gdjs.Level_325Code.GDDinoDouxObjects1});
gdjs.Level_325Code.mapOfGDgdjs_9546Level_9595325Code_9546GDBlueSmallPlantObjects1Objects = Hashtable.newFrom({"BlueSmallPlant": gdjs.Level_325Code.GDBlueSmallPlantObjects1});
gdjs.Level_325Code.mapOfGDgdjs_9546Level_9595325Code_9546GDDinoDouxObjects1Objects = Hashtable.newFrom({"DinoDoux": gdjs.Level_325Code.GDDinoDouxObjects1});
gdjs.Level_325Code.mapOfGDgdjs_9546Level_9595325Code_9546GDRock2Objects1Objects = Hashtable.newFrom({"Rock2": gdjs.Level_325Code.GDRock2Objects1});
gdjs.Level_325Code.mapOfGDgdjs_9546Level_9595325Code_9546GDDinoDouxObjects1Objects = Hashtable.newFrom({"DinoDoux": gdjs.Level_325Code.GDDinoDouxObjects1});
gdjs.Level_325Code.mapOfGDgdjs_9546Level_9595325Code_9546GDBlueFlowerObjects1Objects = Hashtable.newFrom({"BlueFlower": gdjs.Level_325Code.GDBlueFlowerObjects1});
gdjs.Level_325Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BlueSmallPlant"), gdjs.Level_325Code.GDBlueSmallPlantObjects1);
gdjs.copyArray(runtimeScene.getObjects("DinoDoux"), gdjs.Level_325Code.GDDinoDouxObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_325Code.mapOfGDgdjs_9546Level_9595325Code_9546GDDinoDouxObjects1Objects, gdjs.Level_325Code.mapOfGDgdjs_9546Level_9595325Code_9546GDBlueSmallPlantObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "you got trolled level 5", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DinoDoux"), gdjs.Level_325Code.GDDinoDouxObjects1);
gdjs.copyArray(runtimeScene.getObjects("Rock2"), gdjs.Level_325Code.GDRock2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_325Code.mapOfGDgdjs_9546Level_9595325Code_9546GDDinoDouxObjects1Objects, gdjs.Level_325Code.mapOfGDgdjs_9546Level_9595325Code_9546GDRock2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level 5", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlueFlower"), gdjs.Level_325Code.GDBlueFlowerObjects1);
gdjs.copyArray(runtimeScene.getObjects("DinoDoux"), gdjs.Level_325Code.GDDinoDouxObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_325Code.mapOfGDgdjs_9546Level_9595325Code_9546GDDinoDouxObjects1Objects, gdjs.Level_325Code.mapOfGDgdjs_9546Level_9595325Code_9546GDBlueFlowerObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level 6", false);
}}

}


};

gdjs.Level_325Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level_325Code.GDGreenLeaves2Objects1.length = 0;
gdjs.Level_325Code.GDGreenLeaves2Objects2.length = 0;
gdjs.Level_325Code.GDDinoDouxObjects1.length = 0;
gdjs.Level_325Code.GDDinoDouxObjects2.length = 0;
gdjs.Level_325Code.GDNewTextObjects1.length = 0;
gdjs.Level_325Code.GDNewTextObjects2.length = 0;
gdjs.Level_325Code.GDOrangeLeaves2Objects1.length = 0;
gdjs.Level_325Code.GDOrangeLeaves2Objects2.length = 0;
gdjs.Level_325Code.GDGreenBush5Objects1.length = 0;
gdjs.Level_325Code.GDGreenBush5Objects2.length = 0;
gdjs.Level_325Code.GDGreenBush6Objects1.length = 0;
gdjs.Level_325Code.GDGreenBush6Objects2.length = 0;
gdjs.Level_325Code.GDBlueSmallPlantObjects1.length = 0;
gdjs.Level_325Code.GDBlueSmallPlantObjects2.length = 0;
gdjs.Level_325Code.GDNewText2Objects1.length = 0;
gdjs.Level_325Code.GDNewText2Objects2.length = 0;
gdjs.Level_325Code.GDBlueFlowerObjects1.length = 0;
gdjs.Level_325Code.GDBlueFlowerObjects2.length = 0;
gdjs.Level_325Code.GDNewText3Objects1.length = 0;
gdjs.Level_325Code.GDNewText3Objects2.length = 0;
gdjs.Level_325Code.GDRock2Objects1.length = 0;
gdjs.Level_325Code.GDRock2Objects2.length = 0;
gdjs.Level_325Code.GDPlayer_9595currencyObjects1.length = 0;
gdjs.Level_325Code.GDPlayer_9595currencyObjects2.length = 0;
gdjs.Level_325Code.GDGreenLeaves2Objects1.length = 0;
gdjs.Level_325Code.GDGreenLeaves2Objects2.length = 0;
gdjs.Level_325Code.GDDinoDoux2Objects1.length = 0;
gdjs.Level_325Code.GDDinoDoux2Objects2.length = 0;
gdjs.Level_325Code.GDOrangeLeaves3Objects1.length = 0;
gdjs.Level_325Code.GDOrangeLeaves3Objects2.length = 0;
gdjs.Level_325Code.GDGreenBush7Objects1.length = 0;
gdjs.Level_325Code.GDGreenBush7Objects2.length = 0;
gdjs.Level_325Code.GDGreenBush8Objects1.length = 0;
gdjs.Level_325Code.GDGreenBush8Objects2.length = 0;
gdjs.Level_325Code.GDBlueSmallPlant2Objects1.length = 0;
gdjs.Level_325Code.GDBlueSmallPlant2Objects2.length = 0;
gdjs.Level_325Code.GDBlueFlower2Objects1.length = 0;
gdjs.Level_325Code.GDBlueFlower2Objects2.length = 0;
gdjs.Level_325Code.GDRock3Objects1.length = 0;
gdjs.Level_325Code.GDRock3Objects2.length = 0;
gdjs.Level_325Code.GDCircleObjects1.length = 0;
gdjs.Level_325Code.GDCircleObjects2.length = 0;
gdjs.Level_325Code.GDLineLightJoystickObjects1.length = 0;
gdjs.Level_325Code.GDLineLightJoystickObjects2.length = 0;

gdjs.Level_325Code.eventsList0(runtimeScene);
gdjs.Level_325Code.GDGreenLeaves2Objects1.length = 0;
gdjs.Level_325Code.GDGreenLeaves2Objects2.length = 0;
gdjs.Level_325Code.GDDinoDouxObjects1.length = 0;
gdjs.Level_325Code.GDDinoDouxObjects2.length = 0;
gdjs.Level_325Code.GDNewTextObjects1.length = 0;
gdjs.Level_325Code.GDNewTextObjects2.length = 0;
gdjs.Level_325Code.GDOrangeLeaves2Objects1.length = 0;
gdjs.Level_325Code.GDOrangeLeaves2Objects2.length = 0;
gdjs.Level_325Code.GDGreenBush5Objects1.length = 0;
gdjs.Level_325Code.GDGreenBush5Objects2.length = 0;
gdjs.Level_325Code.GDGreenBush6Objects1.length = 0;
gdjs.Level_325Code.GDGreenBush6Objects2.length = 0;
gdjs.Level_325Code.GDBlueSmallPlantObjects1.length = 0;
gdjs.Level_325Code.GDBlueSmallPlantObjects2.length = 0;
gdjs.Level_325Code.GDNewText2Objects1.length = 0;
gdjs.Level_325Code.GDNewText2Objects2.length = 0;
gdjs.Level_325Code.GDBlueFlowerObjects1.length = 0;
gdjs.Level_325Code.GDBlueFlowerObjects2.length = 0;
gdjs.Level_325Code.GDNewText3Objects1.length = 0;
gdjs.Level_325Code.GDNewText3Objects2.length = 0;
gdjs.Level_325Code.GDRock2Objects1.length = 0;
gdjs.Level_325Code.GDRock2Objects2.length = 0;
gdjs.Level_325Code.GDPlayer_9595currencyObjects1.length = 0;
gdjs.Level_325Code.GDPlayer_9595currencyObjects2.length = 0;
gdjs.Level_325Code.GDGreenLeaves2Objects1.length = 0;
gdjs.Level_325Code.GDGreenLeaves2Objects2.length = 0;
gdjs.Level_325Code.GDDinoDoux2Objects1.length = 0;
gdjs.Level_325Code.GDDinoDoux2Objects2.length = 0;
gdjs.Level_325Code.GDOrangeLeaves3Objects1.length = 0;
gdjs.Level_325Code.GDOrangeLeaves3Objects2.length = 0;
gdjs.Level_325Code.GDGreenBush7Objects1.length = 0;
gdjs.Level_325Code.GDGreenBush7Objects2.length = 0;
gdjs.Level_325Code.GDGreenBush8Objects1.length = 0;
gdjs.Level_325Code.GDGreenBush8Objects2.length = 0;
gdjs.Level_325Code.GDBlueSmallPlant2Objects1.length = 0;
gdjs.Level_325Code.GDBlueSmallPlant2Objects2.length = 0;
gdjs.Level_325Code.GDBlueFlower2Objects1.length = 0;
gdjs.Level_325Code.GDBlueFlower2Objects2.length = 0;
gdjs.Level_325Code.GDRock3Objects1.length = 0;
gdjs.Level_325Code.GDRock3Objects2.length = 0;
gdjs.Level_325Code.GDCircleObjects1.length = 0;
gdjs.Level_325Code.GDCircleObjects2.length = 0;
gdjs.Level_325Code.GDLineLightJoystickObjects1.length = 0;
gdjs.Level_325Code.GDLineLightJoystickObjects2.length = 0;


return;

}

gdjs['Level_325Code'] = gdjs.Level_325Code;
