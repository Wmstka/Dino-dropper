gdjs.Level_3210Code = {};
gdjs.Level_3210Code.localVariables = [];
gdjs.Level_3210Code.GDPlayer_9595currency2Objects1= [];
gdjs.Level_3210Code.GDPlayer_9595currency2Objects2= [];
gdjs.Level_3210Code.GDPlayer_9595currency3Objects1= [];
gdjs.Level_3210Code.GDPlayer_9595currency3Objects2= [];
gdjs.Level_3210Code.GDPlayer_9595currency4Objects1= [];
gdjs.Level_3210Code.GDPlayer_9595currency4Objects2= [];
gdjs.Level_3210Code.GDPlayer_9595currency5Objects1= [];
gdjs.Level_3210Code.GDPlayer_9595currency5Objects2= [];
gdjs.Level_3210Code.GDPlayer_9595currency6Objects1= [];
gdjs.Level_3210Code.GDPlayer_9595currency6Objects2= [];
gdjs.Level_3210Code.GDPlayer_9595currency7Objects1= [];
gdjs.Level_3210Code.GDPlayer_9595currency7Objects2= [];
gdjs.Level_3210Code.GDPlayer_9595currencyObjects1= [];
gdjs.Level_3210Code.GDPlayer_9595currencyObjects2= [];
gdjs.Level_3210Code.GDGreenLeaves2Objects1= [];
gdjs.Level_3210Code.GDGreenLeaves2Objects2= [];
gdjs.Level_3210Code.GDDinoDoux2Objects1= [];
gdjs.Level_3210Code.GDDinoDoux2Objects2= [];
gdjs.Level_3210Code.GDOrangeLeaves3Objects1= [];
gdjs.Level_3210Code.GDOrangeLeaves3Objects2= [];
gdjs.Level_3210Code.GDGreenBush7Objects1= [];
gdjs.Level_3210Code.GDGreenBush7Objects2= [];
gdjs.Level_3210Code.GDGreenBush8Objects1= [];
gdjs.Level_3210Code.GDGreenBush8Objects2= [];
gdjs.Level_3210Code.GDBlueSmallPlant2Objects1= [];
gdjs.Level_3210Code.GDBlueSmallPlant2Objects2= [];
gdjs.Level_3210Code.GDBlueFlower2Objects1= [];
gdjs.Level_3210Code.GDBlueFlower2Objects2= [];
gdjs.Level_3210Code.GDRock3Objects1= [];
gdjs.Level_3210Code.GDRock3Objects2= [];
gdjs.Level_3210Code.GDCircleObjects1= [];
gdjs.Level_3210Code.GDCircleObjects2= [];
gdjs.Level_3210Code.GDLineLightJoystickObjects1= [];
gdjs.Level_3210Code.GDLineLightJoystickObjects2= [];


gdjs.Level_3210Code.mapOfGDgdjs_9546Level_95953210Code_9546GDDinoDoux2Objects1Objects = Hashtable.newFrom({"DinoDoux2": gdjs.Level_3210Code.GDDinoDoux2Objects1});
gdjs.Level_3210Code.mapOfGDgdjs_9546Level_95953210Code_9546GDBlueSmallPlant2Objects1Objects = Hashtable.newFrom({"BlueSmallPlant2": gdjs.Level_3210Code.GDBlueSmallPlant2Objects1});
gdjs.Level_3210Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BlueSmallPlant2"), gdjs.Level_3210Code.GDBlueSmallPlant2Objects1);
gdjs.copyArray(runtimeScene.getObjects("DinoDoux2"), gdjs.Level_3210Code.GDDinoDoux2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_3210Code.mapOfGDgdjs_9546Level_95953210Code_9546GDDinoDoux2Objects1Objects, gdjs.Level_3210Code.mapOfGDgdjs_9546Level_95953210Code_9546GDBlueSmallPlant2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level 10", false);
}}

}


};

gdjs.Level_3210Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level_3210Code.GDPlayer_9595currency2Objects1.length = 0;
gdjs.Level_3210Code.GDPlayer_9595currency2Objects2.length = 0;
gdjs.Level_3210Code.GDPlayer_9595currency3Objects1.length = 0;
gdjs.Level_3210Code.GDPlayer_9595currency3Objects2.length = 0;
gdjs.Level_3210Code.GDPlayer_9595currency4Objects1.length = 0;
gdjs.Level_3210Code.GDPlayer_9595currency4Objects2.length = 0;
gdjs.Level_3210Code.GDPlayer_9595currency5Objects1.length = 0;
gdjs.Level_3210Code.GDPlayer_9595currency5Objects2.length = 0;
gdjs.Level_3210Code.GDPlayer_9595currency6Objects1.length = 0;
gdjs.Level_3210Code.GDPlayer_9595currency6Objects2.length = 0;
gdjs.Level_3210Code.GDPlayer_9595currency7Objects1.length = 0;
gdjs.Level_3210Code.GDPlayer_9595currency7Objects2.length = 0;
gdjs.Level_3210Code.GDPlayer_9595currencyObjects1.length = 0;
gdjs.Level_3210Code.GDPlayer_9595currencyObjects2.length = 0;
gdjs.Level_3210Code.GDGreenLeaves2Objects1.length = 0;
gdjs.Level_3210Code.GDGreenLeaves2Objects2.length = 0;
gdjs.Level_3210Code.GDDinoDoux2Objects1.length = 0;
gdjs.Level_3210Code.GDDinoDoux2Objects2.length = 0;
gdjs.Level_3210Code.GDOrangeLeaves3Objects1.length = 0;
gdjs.Level_3210Code.GDOrangeLeaves3Objects2.length = 0;
gdjs.Level_3210Code.GDGreenBush7Objects1.length = 0;
gdjs.Level_3210Code.GDGreenBush7Objects2.length = 0;
gdjs.Level_3210Code.GDGreenBush8Objects1.length = 0;
gdjs.Level_3210Code.GDGreenBush8Objects2.length = 0;
gdjs.Level_3210Code.GDBlueSmallPlant2Objects1.length = 0;
gdjs.Level_3210Code.GDBlueSmallPlant2Objects2.length = 0;
gdjs.Level_3210Code.GDBlueFlower2Objects1.length = 0;
gdjs.Level_3210Code.GDBlueFlower2Objects2.length = 0;
gdjs.Level_3210Code.GDRock3Objects1.length = 0;
gdjs.Level_3210Code.GDRock3Objects2.length = 0;
gdjs.Level_3210Code.GDCircleObjects1.length = 0;
gdjs.Level_3210Code.GDCircleObjects2.length = 0;
gdjs.Level_3210Code.GDLineLightJoystickObjects1.length = 0;
gdjs.Level_3210Code.GDLineLightJoystickObjects2.length = 0;

gdjs.Level_3210Code.eventsList0(runtimeScene);
gdjs.Level_3210Code.GDPlayer_9595currency2Objects1.length = 0;
gdjs.Level_3210Code.GDPlayer_9595currency2Objects2.length = 0;
gdjs.Level_3210Code.GDPlayer_9595currency3Objects1.length = 0;
gdjs.Level_3210Code.GDPlayer_9595currency3Objects2.length = 0;
gdjs.Level_3210Code.GDPlayer_9595currency4Objects1.length = 0;
gdjs.Level_3210Code.GDPlayer_9595currency4Objects2.length = 0;
gdjs.Level_3210Code.GDPlayer_9595currency5Objects1.length = 0;
gdjs.Level_3210Code.GDPlayer_9595currency5Objects2.length = 0;
gdjs.Level_3210Code.GDPlayer_9595currency6Objects1.length = 0;
gdjs.Level_3210Code.GDPlayer_9595currency6Objects2.length = 0;
gdjs.Level_3210Code.GDPlayer_9595currency7Objects1.length = 0;
gdjs.Level_3210Code.GDPlayer_9595currency7Objects2.length = 0;
gdjs.Level_3210Code.GDPlayer_9595currencyObjects1.length = 0;
gdjs.Level_3210Code.GDPlayer_9595currencyObjects2.length = 0;
gdjs.Level_3210Code.GDGreenLeaves2Objects1.length = 0;
gdjs.Level_3210Code.GDGreenLeaves2Objects2.length = 0;
gdjs.Level_3210Code.GDDinoDoux2Objects1.length = 0;
gdjs.Level_3210Code.GDDinoDoux2Objects2.length = 0;
gdjs.Level_3210Code.GDOrangeLeaves3Objects1.length = 0;
gdjs.Level_3210Code.GDOrangeLeaves3Objects2.length = 0;
gdjs.Level_3210Code.GDGreenBush7Objects1.length = 0;
gdjs.Level_3210Code.GDGreenBush7Objects2.length = 0;
gdjs.Level_3210Code.GDGreenBush8Objects1.length = 0;
gdjs.Level_3210Code.GDGreenBush8Objects2.length = 0;
gdjs.Level_3210Code.GDBlueSmallPlant2Objects1.length = 0;
gdjs.Level_3210Code.GDBlueSmallPlant2Objects2.length = 0;
gdjs.Level_3210Code.GDBlueFlower2Objects1.length = 0;
gdjs.Level_3210Code.GDBlueFlower2Objects2.length = 0;
gdjs.Level_3210Code.GDRock3Objects1.length = 0;
gdjs.Level_3210Code.GDRock3Objects2.length = 0;
gdjs.Level_3210Code.GDCircleObjects1.length = 0;
gdjs.Level_3210Code.GDCircleObjects2.length = 0;
gdjs.Level_3210Code.GDLineLightJoystickObjects1.length = 0;
gdjs.Level_3210Code.GDLineLightJoystickObjects2.length = 0;


return;

}

gdjs['Level_3210Code'] = gdjs.Level_3210Code;
