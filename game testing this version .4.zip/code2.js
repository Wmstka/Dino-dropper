gdjs.tut_47_32Level_321Code = {};
gdjs.tut_47_32Level_321Code.localVariables = [];
gdjs.tut_47_32Level_321Code.GDDinoDouxObjects1= [];
gdjs.tut_47_32Level_321Code.GDDinoDouxObjects2= [];
gdjs.tut_47_32Level_321Code.GDGreenLeavesObjects1= [];
gdjs.tut_47_32Level_321Code.GDGreenLeavesObjects2= [];
gdjs.tut_47_32Level_321Code.GDBigGreenTree1Objects1= [];
gdjs.tut_47_32Level_321Code.GDBigGreenTree1Objects2= [];
gdjs.tut_47_32Level_321Code.GDBigGreenTree4Objects1= [];
gdjs.tut_47_32Level_321Code.GDBigGreenTree4Objects2= [];
gdjs.tut_47_32Level_321Code.GDOrangeLeavesObjects1= [];
gdjs.tut_47_32Level_321Code.GDOrangeLeavesObjects2= [];
gdjs.tut_47_32Level_321Code.GDBigGreenTree2Objects1= [];
gdjs.tut_47_32Level_321Code.GDBigGreenTree2Objects2= [];
gdjs.tut_47_32Level_321Code.GDBigGreenTree3Objects1= [];
gdjs.tut_47_32Level_321Code.GDBigGreenTree3Objects2= [];
gdjs.tut_47_32Level_321Code.GDBigOrangeTree1Objects1= [];
gdjs.tut_47_32Level_321Code.GDBigOrangeTree1Objects2= [];
gdjs.tut_47_32Level_321Code.GDBigGreenTree8Objects1= [];
gdjs.tut_47_32Level_321Code.GDBigGreenTree8Objects2= [];
gdjs.tut_47_32Level_321Code.GDBigGreenTree5Objects1= [];
gdjs.tut_47_32Level_321Code.GDBigGreenTree5Objects2= [];
gdjs.tut_47_32Level_321Code.GDBigGreenTree7Objects1= [];
gdjs.tut_47_32Level_321Code.GDBigGreenTree7Objects2= [];
gdjs.tut_47_32Level_321Code.GDBigGreenTree6Objects1= [];
gdjs.tut_47_32Level_321Code.GDBigGreenTree6Objects2= [];
gdjs.tut_47_32Level_321Code.GDBigOrangeTree2Objects1= [];
gdjs.tut_47_32Level_321Code.GDBigOrangeTree2Objects2= [];
gdjs.tut_47_32Level_321Code.GDBigOrangeTree4Objects1= [];
gdjs.tut_47_32Level_321Code.GDBigOrangeTree4Objects2= [];
gdjs.tut_47_32Level_321Code.GDBigOrangeTree5Objects1= [];
gdjs.tut_47_32Level_321Code.GDBigOrangeTree5Objects2= [];
gdjs.tut_47_32Level_321Code.GDBigOrangeTree6Objects1= [];
gdjs.tut_47_32Level_321Code.GDBigOrangeTree6Objects2= [];
gdjs.tut_47_32Level_321Code.GDBigTreeWithSnow1Objects1= [];
gdjs.tut_47_32Level_321Code.GDBigTreeWithSnow1Objects2= [];
gdjs.tut_47_32Level_321Code.GDBigOrangeTree3Objects1= [];
gdjs.tut_47_32Level_321Code.GDBigOrangeTree3Objects2= [];
gdjs.tut_47_32Level_321Code.GDBigTreeWithSnow2Objects1= [];
gdjs.tut_47_32Level_321Code.GDBigTreeWithSnow2Objects2= [];
gdjs.tut_47_32Level_321Code.GDBlueSmallPlantObjects1= [];
gdjs.tut_47_32Level_321Code.GDBlueSmallPlantObjects2= [];
gdjs.tut_47_32Level_321Code.GDGreenBush1Objects1= [];
gdjs.tut_47_32Level_321Code.GDGreenBush1Objects2= [];
gdjs.tut_47_32Level_321Code.GDBigTreeWithSnow3Objects1= [];
gdjs.tut_47_32Level_321Code.GDBigTreeWithSnow3Objects2= [];
gdjs.tut_47_32Level_321Code.GDBlueFlowerObjects1= [];
gdjs.tut_47_32Level_321Code.GDBlueFlowerObjects2= [];
gdjs.tut_47_32Level_321Code.GDGreenBush2Objects1= [];
gdjs.tut_47_32Level_321Code.GDGreenBush2Objects2= [];
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves1Objects1= [];
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves1Objects2= [];
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves3Objects1= [];
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves3Objects2= [];
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves2Objects1= [];
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves2Objects2= [];
gdjs.tut_47_32Level_321Code.GDGreenBush3Objects1= [];
gdjs.tut_47_32Level_321Code.GDGreenBush3Objects2= [];
gdjs.tut_47_32Level_321Code.GDGreenBush4Objects1= [];
gdjs.tut_47_32Level_321Code.GDGreenBush4Objects2= [];
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves1Objects1= [];
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves1Objects2= [];
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves4Objects1= [];
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves4Objects2= [];
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves6Objects1= [];
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves6Objects2= [];
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves5Objects1= [];
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves5Objects2= [];
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves2Objects1= [];
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves2Objects2= [];
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves7Objects1= [];
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves7Objects2= [];
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves6Objects1= [];
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves6Objects2= [];
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves4Objects1= [];
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves4Objects2= [];
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves5Objects1= [];
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves5Objects2= [];
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves3Objects1= [];
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves3Objects2= [];
gdjs.tut_47_32Level_321Code.GDPurpleSmallPlantObjects1= [];
gdjs.tut_47_32Level_321Code.GDPurpleSmallPlantObjects2= [];
gdjs.tut_47_32Level_321Code.GDRedFlowerObjects1= [];
gdjs.tut_47_32Level_321Code.GDRedFlowerObjects2= [];
gdjs.tut_47_32Level_321Code.GDTrunk1Objects1= [];
gdjs.tut_47_32Level_321Code.GDTrunk1Objects2= [];
gdjs.tut_47_32Level_321Code.GDSmallGrassObjects1= [];
gdjs.tut_47_32Level_321Code.GDSmallGrassObjects2= [];
gdjs.tut_47_32Level_321Code.GDSmallPlant2Objects1= [];
gdjs.tut_47_32Level_321Code.GDSmallPlant2Objects2= [];
gdjs.tut_47_32Level_321Code.GDSmallPlant1Objects1= [];
gdjs.tut_47_32Level_321Code.GDSmallPlant1Objects2= [];
gdjs.tut_47_32Level_321Code.GDTinyGrassObjects1= [];
gdjs.tut_47_32Level_321Code.GDTinyGrassObjects2= [];
gdjs.tut_47_32Level_321Code.GDTrunk3Objects1= [];
gdjs.tut_47_32Level_321Code.GDTrunk3Objects2= [];
gdjs.tut_47_32Level_321Code.GDTrunk2Objects1= [];
gdjs.tut_47_32Level_321Code.GDTrunk2Objects2= [];
gdjs.tut_47_32Level_321Code.GDWhiteTree1Objects1= [];
gdjs.tut_47_32Level_321Code.GDWhiteTree1Objects2= [];
gdjs.tut_47_32Level_321Code.GDWhiteTree2Objects1= [];
gdjs.tut_47_32Level_321Code.GDWhiteTree2Objects2= [];
gdjs.tut_47_32Level_321Code.GDTrunk4Objects1= [];
gdjs.tut_47_32Level_321Code.GDTrunk4Objects2= [];
gdjs.tut_47_32Level_321Code.GDWhiteTree3Objects1= [];
gdjs.tut_47_32Level_321Code.GDWhiteTree3Objects2= [];
gdjs.tut_47_32Level_321Code.GDWhiteTrunk3Objects1= [];
gdjs.tut_47_32Level_321Code.GDWhiteTrunk3Objects2= [];
gdjs.tut_47_32Level_321Code.GDWhiteTrunk2Objects1= [];
gdjs.tut_47_32Level_321Code.GDWhiteTrunk2Objects2= [];
gdjs.tut_47_32Level_321Code.GDWhiteTrunk4Objects1= [];
gdjs.tut_47_32Level_321Code.GDWhiteTrunk4Objects2= [];
gdjs.tut_47_32Level_321Code.GDWhiteTrunkObjects1= [];
gdjs.tut_47_32Level_321Code.GDWhiteTrunkObjects2= [];
gdjs.tut_47_32Level_321Code.GDRock1Objects1= [];
gdjs.tut_47_32Level_321Code.GDRock1Objects2= [];
gdjs.tut_47_32Level_321Code.GDRock2Objects1= [];
gdjs.tut_47_32Level_321Code.GDRock2Objects2= [];
gdjs.tut_47_32Level_321Code.GDRock3Objects1= [];
gdjs.tut_47_32Level_321Code.GDRock3Objects2= [];
gdjs.tut_47_32Level_321Code.GDRock4Objects1= [];
gdjs.tut_47_32Level_321Code.GDRock4Objects2= [];
gdjs.tut_47_32Level_321Code.GDRock5Objects1= [];
gdjs.tut_47_32Level_321Code.GDRock5Objects2= [];
gdjs.tut_47_32Level_321Code.GDJump_9595off_9595bush_9595TEXTObjects1= [];
gdjs.tut_47_32Level_321Code.GDJump_9595off_9595bush_9595TEXTObjects2= [];
gdjs.tut_47_32Level_321Code.GDdont_9595fall_9595off_9595the_9595map_9595TEXTObjects1= [];
gdjs.tut_47_32Level_321Code.GDdont_9595fall_9595off_9595the_9595map_9595TEXTObjects2= [];
gdjs.tut_47_32Level_321Code.GDIntro_9595TEXTObjects1= [];
gdjs.tut_47_32Level_321Code.GDIntro_9595TEXTObjects2= [];
gdjs.tut_47_32Level_321Code.GDFake_9595bushes_9595TEXTObjects1= [];
gdjs.tut_47_32Level_321Code.GDFake_9595bushes_9595TEXTObjects2= [];
gdjs.tut_47_32Level_321Code.GDreal_9595bushes_9595TEXTObjects1= [];
gdjs.tut_47_32Level_321Code.GDreal_9595bushes_9595TEXTObjects2= [];
gdjs.tut_47_32Level_321Code.GDyour_9595save_9595TEXTObjects1= [];
gdjs.tut_47_32Level_321Code.GDyour_9595save_9595TEXTObjects2= [];
gdjs.tut_47_32Level_321Code.GDlv_95951_9595complete_9595TEXTObjects1= [];
gdjs.tut_47_32Level_321Code.GDlv_95951_9595complete_9595TEXTObjects2= [];
gdjs.tut_47_32Level_321Code.GDNewPanelSpriteObjects1= [];
gdjs.tut_47_32Level_321Code.GDNewPanelSpriteObjects2= [];
gdjs.tut_47_32Level_321Code.GDCOntrolls_9595TEXTObjects1= [];
gdjs.tut_47_32Level_321Code.GDCOntrolls_9595TEXTObjects2= [];
gdjs.tut_47_32Level_321Code.GDGreenLeaves2Objects1= [];
gdjs.tut_47_32Level_321Code.GDGreenLeaves2Objects2= [];
gdjs.tut_47_32Level_321Code.GDOrangeLeaves2Objects1= [];
gdjs.tut_47_32Level_321Code.GDOrangeLeaves2Objects2= [];
gdjs.tut_47_32Level_321Code.GDGreenBush5Objects1= [];
gdjs.tut_47_32Level_321Code.GDGreenBush5Objects2= [];
gdjs.tut_47_32Level_321Code.GDGreenBush6Objects1= [];
gdjs.tut_47_32Level_321Code.GDGreenBush6Objects2= [];
gdjs.tut_47_32Level_321Code.GDlv_95951_9595complete_9595TEXT2Objects1= [];
gdjs.tut_47_32Level_321Code.GDlv_95951_9595complete_9595TEXT2Objects2= [];
gdjs.tut_47_32Level_321Code.GDSmallGreenPlasticRoundToggleObjects1= [];
gdjs.tut_47_32Level_321Code.GDSmallGreenPlasticRoundToggleObjects2= [];
gdjs.tut_47_32Level_321Code.GDPlayer_9595currencyObjects1= [];
gdjs.tut_47_32Level_321Code.GDPlayer_9595currencyObjects2= [];
gdjs.tut_47_32Level_321Code.GDGreenLeaves2Objects1= [];
gdjs.tut_47_32Level_321Code.GDGreenLeaves2Objects2= [];
gdjs.tut_47_32Level_321Code.GDDinoDoux2Objects1= [];
gdjs.tut_47_32Level_321Code.GDDinoDoux2Objects2= [];
gdjs.tut_47_32Level_321Code.GDOrangeLeaves3Objects1= [];
gdjs.tut_47_32Level_321Code.GDOrangeLeaves3Objects2= [];
gdjs.tut_47_32Level_321Code.GDGreenBush7Objects1= [];
gdjs.tut_47_32Level_321Code.GDGreenBush7Objects2= [];
gdjs.tut_47_32Level_321Code.GDGreenBush8Objects1= [];
gdjs.tut_47_32Level_321Code.GDGreenBush8Objects2= [];
gdjs.tut_47_32Level_321Code.GDBlueSmallPlant2Objects1= [];
gdjs.tut_47_32Level_321Code.GDBlueSmallPlant2Objects2= [];
gdjs.tut_47_32Level_321Code.GDBlueFlower2Objects1= [];
gdjs.tut_47_32Level_321Code.GDBlueFlower2Objects2= [];
gdjs.tut_47_32Level_321Code.GDRock3Objects1= [];
gdjs.tut_47_32Level_321Code.GDRock3Objects2= [];
gdjs.tut_47_32Level_321Code.GDCircleObjects1= [];
gdjs.tut_47_32Level_321Code.GDCircleObjects2= [];
gdjs.tut_47_32Level_321Code.GDLineLightJoystickObjects1= [];
gdjs.tut_47_32Level_321Code.GDLineLightJoystickObjects2= [];


gdjs.tut_47_32Level_321Code.mapOfGDgdjs_9546tut_959547_959532Level_9595321Code_9546GDDinoDouxObjects1Objects = Hashtable.newFrom({"DinoDoux": gdjs.tut_47_32Level_321Code.GDDinoDouxObjects1});
gdjs.tut_47_32Level_321Code.mapOfGDgdjs_9546tut_959547_959532Level_9595321Code_9546GDBlueFlowerObjects1Objects = Hashtable.newFrom({"BlueFlower": gdjs.tut_47_32Level_321Code.GDBlueFlowerObjects1});
gdjs.tut_47_32Level_321Code.mapOfGDgdjs_9546tut_959547_959532Level_9595321Code_9546GDDinoDouxObjects1Objects = Hashtable.newFrom({"DinoDoux": gdjs.tut_47_32Level_321Code.GDDinoDouxObjects1});
gdjs.tut_47_32Level_321Code.mapOfGDgdjs_9546tut_959547_959532Level_9595321Code_9546GDRock2Objects1Objects = Hashtable.newFrom({"Rock2": gdjs.tut_47_32Level_321Code.GDRock2Objects1});
gdjs.tut_47_32Level_321Code.mapOfGDgdjs_9546tut_959547_959532Level_9595321Code_9546GDDinoDouxObjects1Objects = Hashtable.newFrom({"DinoDoux": gdjs.tut_47_32Level_321Code.GDDinoDouxObjects1});
gdjs.tut_47_32Level_321Code.mapOfGDgdjs_9546tut_959547_959532Level_9595321Code_9546GDBlueFlowerObjects1Objects = Hashtable.newFrom({"BlueFlower": gdjs.tut_47_32Level_321Code.GDBlueFlowerObjects1});
gdjs.tut_47_32Level_321Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BlueFlower"), gdjs.tut_47_32Level_321Code.GDBlueFlowerObjects1);
gdjs.copyArray(runtimeScene.getObjects("DinoDoux"), gdjs.tut_47_32Level_321Code.GDDinoDouxObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.tut_47_32Level_321Code.mapOfGDgdjs_9546tut_959547_959532Level_9595321Code_9546GDDinoDouxObjects1Objects, gdjs.tut_47_32Level_321Code.mapOfGDgdjs_9546tut_959547_959532Level_9595321Code_9546GDBlueFlowerObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "level 2", false);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("DinoDoux"), gdjs.tut_47_32Level_321Code.GDDinoDouxObjects1);
gdjs.copyArray(runtimeScene.getObjects("Rock2"), gdjs.tut_47_32Level_321Code.GDRock2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.tut_47_32Level_321Code.mapOfGDgdjs_9546tut_959547_959532Level_9595321Code_9546GDDinoDouxObjects1Objects, gdjs.tut_47_32Level_321Code.mapOfGDgdjs_9546tut_959547_959532Level_9595321Code_9546GDRock2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "tut/ Level 1", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlueFlower"), gdjs.tut_47_32Level_321Code.GDBlueFlowerObjects1);
gdjs.copyArray(runtimeScene.getObjects("DinoDoux"), gdjs.tut_47_32Level_321Code.GDDinoDouxObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.tut_47_32Level_321Code.mapOfGDgdjs_9546tut_959547_959532Level_9595321Code_9546GDDinoDouxObjects1Objects, gdjs.tut_47_32Level_321Code.mapOfGDgdjs_9546tut_959547_959532Level_9595321Code_9546GDBlueFlowerObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() > 1);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player_currency"), gdjs.tut_47_32Level_321Code.GDPlayer_9595currencyObjects1);
{for(var i = 0, len = gdjs.tut_47_32Level_321Code.GDPlayer_9595currencyObjects1.length ;i < len;++i) {
    gdjs.tut_47_32Level_321Code.GDPlayer_9595currencyObjects1[i].getBehavior("Text").setText(gdjs.tut_47_32Level_321Code.GDPlayer_9595currencyObjects1[i].getBehavior("Text").getText() + ("1"));
}
}}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main menu", false);
}}

}


};

gdjs.tut_47_32Level_321Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.tut_47_32Level_321Code.GDDinoDouxObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDDinoDouxObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenLeavesObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenLeavesObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigGreenTree1Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigGreenTree1Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigGreenTree4Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigGreenTree4Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeLeavesObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeLeavesObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigGreenTree2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigGreenTree2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigGreenTree3Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigGreenTree3Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigOrangeTree1Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigOrangeTree1Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigGreenTree8Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigGreenTree8Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigGreenTree5Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigGreenTree5Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigGreenTree7Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigGreenTree7Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigGreenTree6Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigGreenTree6Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigOrangeTree2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigOrangeTree2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigOrangeTree4Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigOrangeTree4Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigOrangeTree5Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigOrangeTree5Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigOrangeTree6Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigOrangeTree6Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigTreeWithSnow1Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigTreeWithSnow1Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigOrangeTree3Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigOrangeTree3Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigTreeWithSnow2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigTreeWithSnow2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBlueSmallPlantObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBlueSmallPlantObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenBush1Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenBush1Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigTreeWithSnow3Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigTreeWithSnow3Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBlueFlowerObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBlueFlowerObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenBush2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenBush2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves1Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves1Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves3Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves3Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenBush3Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenBush3Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenBush4Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenBush4Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves1Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves1Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves4Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves4Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves6Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves6Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves5Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves5Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves7Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves7Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves6Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves6Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves4Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves4Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves5Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves5Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves3Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves3Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDPurpleSmallPlantObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDPurpleSmallPlantObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDRedFlowerObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDRedFlowerObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDTrunk1Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDTrunk1Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDSmallGrassObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDSmallGrassObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDSmallPlant2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDSmallPlant2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDSmallPlant1Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDSmallPlant1Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDTinyGrassObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDTinyGrassObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDTrunk3Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDTrunk3Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDTrunk2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDTrunk2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDWhiteTree1Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDWhiteTree1Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDWhiteTree2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDWhiteTree2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDTrunk4Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDTrunk4Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDWhiteTree3Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDWhiteTree3Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDWhiteTrunk3Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDWhiteTrunk3Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDWhiteTrunk2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDWhiteTrunk2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDWhiteTrunk4Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDWhiteTrunk4Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDWhiteTrunkObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDWhiteTrunkObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDRock1Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDRock1Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDRock2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDRock2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDRock3Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDRock3Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDRock4Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDRock4Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDRock5Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDRock5Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDJump_9595off_9595bush_9595TEXTObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDJump_9595off_9595bush_9595TEXTObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDdont_9595fall_9595off_9595the_9595map_9595TEXTObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDdont_9595fall_9595off_9595the_9595map_9595TEXTObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDIntro_9595TEXTObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDIntro_9595TEXTObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDFake_9595bushes_9595TEXTObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDFake_9595bushes_9595TEXTObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDreal_9595bushes_9595TEXTObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDreal_9595bushes_9595TEXTObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDyour_9595save_9595TEXTObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDyour_9595save_9595TEXTObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDlv_95951_9595complete_9595TEXTObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDlv_95951_9595complete_9595TEXTObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDNewPanelSpriteObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDNewPanelSpriteObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDCOntrolls_9595TEXTObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDCOntrolls_9595TEXTObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenLeaves2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenLeaves2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeLeaves2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeLeaves2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenBush5Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenBush5Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenBush6Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenBush6Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDlv_95951_9595complete_9595TEXT2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDlv_95951_9595complete_9595TEXT2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDSmallGreenPlasticRoundToggleObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDSmallGreenPlasticRoundToggleObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDPlayer_9595currencyObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDPlayer_9595currencyObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenLeaves2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenLeaves2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDDinoDoux2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDDinoDoux2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeLeaves3Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeLeaves3Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenBush7Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenBush7Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenBush8Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenBush8Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBlueSmallPlant2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBlueSmallPlant2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBlueFlower2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBlueFlower2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDRock3Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDRock3Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDCircleObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDCircleObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDLineLightJoystickObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDLineLightJoystickObjects2.length = 0;

gdjs.tut_47_32Level_321Code.eventsList0(runtimeScene);
gdjs.tut_47_32Level_321Code.GDDinoDouxObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDDinoDouxObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenLeavesObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenLeavesObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigGreenTree1Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigGreenTree1Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigGreenTree4Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigGreenTree4Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeLeavesObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeLeavesObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigGreenTree2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigGreenTree2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigGreenTree3Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigGreenTree3Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigOrangeTree1Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigOrangeTree1Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigGreenTree8Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigGreenTree8Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigGreenTree5Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigGreenTree5Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigGreenTree7Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigGreenTree7Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigGreenTree6Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigGreenTree6Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigOrangeTree2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigOrangeTree2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigOrangeTree4Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigOrangeTree4Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigOrangeTree5Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigOrangeTree5Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigOrangeTree6Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigOrangeTree6Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigTreeWithSnow1Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigTreeWithSnow1Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigOrangeTree3Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigOrangeTree3Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigTreeWithSnow2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigTreeWithSnow2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBlueSmallPlantObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBlueSmallPlantObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenBush1Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenBush1Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBigTreeWithSnow3Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBigTreeWithSnow3Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBlueFlowerObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBlueFlowerObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenBush2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenBush2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves1Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves1Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves3Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves3Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenBush3Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenBush3Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenBush4Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenBush4Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves1Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves1Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves4Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves4Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves6Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves6Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves5Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves5Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves7Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenTreeLeaves7Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves6Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves6Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves4Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves4Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves5Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves5Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves3Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeTreeLeaves3Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDPurpleSmallPlantObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDPurpleSmallPlantObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDRedFlowerObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDRedFlowerObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDTrunk1Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDTrunk1Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDSmallGrassObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDSmallGrassObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDSmallPlant2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDSmallPlant2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDSmallPlant1Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDSmallPlant1Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDTinyGrassObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDTinyGrassObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDTrunk3Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDTrunk3Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDTrunk2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDTrunk2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDWhiteTree1Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDWhiteTree1Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDWhiteTree2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDWhiteTree2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDTrunk4Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDTrunk4Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDWhiteTree3Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDWhiteTree3Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDWhiteTrunk3Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDWhiteTrunk3Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDWhiteTrunk2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDWhiteTrunk2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDWhiteTrunk4Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDWhiteTrunk4Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDWhiteTrunkObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDWhiteTrunkObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDRock1Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDRock1Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDRock2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDRock2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDRock3Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDRock3Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDRock4Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDRock4Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDRock5Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDRock5Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDJump_9595off_9595bush_9595TEXTObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDJump_9595off_9595bush_9595TEXTObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDdont_9595fall_9595off_9595the_9595map_9595TEXTObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDdont_9595fall_9595off_9595the_9595map_9595TEXTObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDIntro_9595TEXTObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDIntro_9595TEXTObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDFake_9595bushes_9595TEXTObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDFake_9595bushes_9595TEXTObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDreal_9595bushes_9595TEXTObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDreal_9595bushes_9595TEXTObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDyour_9595save_9595TEXTObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDyour_9595save_9595TEXTObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDlv_95951_9595complete_9595TEXTObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDlv_95951_9595complete_9595TEXTObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDNewPanelSpriteObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDNewPanelSpriteObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDCOntrolls_9595TEXTObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDCOntrolls_9595TEXTObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenLeaves2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenLeaves2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeLeaves2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeLeaves2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenBush5Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenBush5Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenBush6Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenBush6Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDlv_95951_9595complete_9595TEXT2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDlv_95951_9595complete_9595TEXT2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDSmallGreenPlasticRoundToggleObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDSmallGreenPlasticRoundToggleObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDPlayer_9595currencyObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDPlayer_9595currencyObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenLeaves2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenLeaves2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDDinoDoux2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDDinoDoux2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeLeaves3Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDOrangeLeaves3Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenBush7Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenBush7Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenBush8Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDGreenBush8Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBlueSmallPlant2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBlueSmallPlant2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDBlueFlower2Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDBlueFlower2Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDRock3Objects1.length = 0;
gdjs.tut_47_32Level_321Code.GDRock3Objects2.length = 0;
gdjs.tut_47_32Level_321Code.GDCircleObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDCircleObjects2.length = 0;
gdjs.tut_47_32Level_321Code.GDLineLightJoystickObjects1.length = 0;
gdjs.tut_47_32Level_321Code.GDLineLightJoystickObjects2.length = 0;


return;

}

gdjs['tut_47_32Level_321Code'] = gdjs.tut_47_32Level_321Code;
