gdjs.you_32got_32trolled_32level_325Code = {};
gdjs.you_32got_32trolled_32level_325Code.localVariables = [];
gdjs.you_32got_32trolled_32level_325Code.GDDinoDouxObjects1= [];
gdjs.you_32got_32trolled_32level_325Code.GDDinoDouxObjects2= [];
gdjs.you_32got_32trolled_32level_325Code.GDGreenLeaves2Objects1= [];
gdjs.you_32got_32trolled_32level_325Code.GDGreenLeaves2Objects2= [];
gdjs.you_32got_32trolled_32level_325Code.GDBlueSmallPlantObjects1= [];
gdjs.you_32got_32trolled_32level_325Code.GDBlueSmallPlantObjects2= [];
gdjs.you_32got_32trolled_32level_325Code.GDNewTextObjects1= [];
gdjs.you_32got_32trolled_32level_325Code.GDNewTextObjects2= [];
gdjs.you_32got_32trolled_32level_325Code.GDPlayer_9595currencyObjects1= [];
gdjs.you_32got_32trolled_32level_325Code.GDPlayer_9595currencyObjects2= [];
gdjs.you_32got_32trolled_32level_325Code.GDGreenLeaves2Objects1= [];
gdjs.you_32got_32trolled_32level_325Code.GDGreenLeaves2Objects2= [];
gdjs.you_32got_32trolled_32level_325Code.GDDinoDoux2Objects1= [];
gdjs.you_32got_32trolled_32level_325Code.GDDinoDoux2Objects2= [];
gdjs.you_32got_32trolled_32level_325Code.GDOrangeLeaves3Objects1= [];
gdjs.you_32got_32trolled_32level_325Code.GDOrangeLeaves3Objects2= [];
gdjs.you_32got_32trolled_32level_325Code.GDGreenBush7Objects1= [];
gdjs.you_32got_32trolled_32level_325Code.GDGreenBush7Objects2= [];
gdjs.you_32got_32trolled_32level_325Code.GDGreenBush8Objects1= [];
gdjs.you_32got_32trolled_32level_325Code.GDGreenBush8Objects2= [];
gdjs.you_32got_32trolled_32level_325Code.GDBlueSmallPlant2Objects1= [];
gdjs.you_32got_32trolled_32level_325Code.GDBlueSmallPlant2Objects2= [];
gdjs.you_32got_32trolled_32level_325Code.GDBlueFlower2Objects1= [];
gdjs.you_32got_32trolled_32level_325Code.GDBlueFlower2Objects2= [];
gdjs.you_32got_32trolled_32level_325Code.GDRock3Objects1= [];
gdjs.you_32got_32trolled_32level_325Code.GDRock3Objects2= [];
gdjs.you_32got_32trolled_32level_325Code.GDCircleObjects1= [];
gdjs.you_32got_32trolled_32level_325Code.GDCircleObjects2= [];
gdjs.you_32got_32trolled_32level_325Code.GDLineLightJoystickObjects1= [];
gdjs.you_32got_32trolled_32level_325Code.GDLineLightJoystickObjects2= [];


gdjs.you_32got_32trolled_32level_325Code.mapOfGDgdjs_9546you_959532got_959532trolled_959532level_9595325Code_9546GDDinoDouxObjects1Objects = Hashtable.newFrom({"DinoDoux": gdjs.you_32got_32trolled_32level_325Code.GDDinoDouxObjects1});
gdjs.you_32got_32trolled_32level_325Code.mapOfGDgdjs_9546you_959532got_959532trolled_959532level_9595325Code_9546GDBlueSmallPlantObjects1Objects = Hashtable.newFrom({"BlueSmallPlant": gdjs.you_32got_32trolled_32level_325Code.GDBlueSmallPlantObjects1});
gdjs.you_32got_32trolled_32level_325Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BlueSmallPlant"), gdjs.you_32got_32trolled_32level_325Code.GDBlueSmallPlantObjects1);
gdjs.copyArray(runtimeScene.getObjects("DinoDoux"), gdjs.you_32got_32trolled_32level_325Code.GDDinoDouxObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.you_32got_32trolled_32level_325Code.mapOfGDgdjs_9546you_959532got_959532trolled_959532level_9595325Code_9546GDDinoDouxObjects1Objects, gdjs.you_32got_32trolled_32level_325Code.mapOfGDgdjs_9546you_959532got_959532trolled_959532level_9595325Code_9546GDBlueSmallPlantObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level 5", false);
}}

}


};

gdjs.you_32got_32trolled_32level_325Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.you_32got_32trolled_32level_325Code.GDDinoDouxObjects1.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDDinoDouxObjects2.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDGreenLeaves2Objects1.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDGreenLeaves2Objects2.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDBlueSmallPlantObjects1.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDBlueSmallPlantObjects2.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDNewTextObjects1.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDNewTextObjects2.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDPlayer_9595currencyObjects1.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDPlayer_9595currencyObjects2.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDGreenLeaves2Objects1.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDGreenLeaves2Objects2.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDDinoDoux2Objects1.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDDinoDoux2Objects2.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDOrangeLeaves3Objects1.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDOrangeLeaves3Objects2.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDGreenBush7Objects1.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDGreenBush7Objects2.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDGreenBush8Objects1.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDGreenBush8Objects2.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDBlueSmallPlant2Objects1.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDBlueSmallPlant2Objects2.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDBlueFlower2Objects1.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDBlueFlower2Objects2.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDRock3Objects1.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDRock3Objects2.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDCircleObjects1.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDCircleObjects2.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDLineLightJoystickObjects1.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDLineLightJoystickObjects2.length = 0;

gdjs.you_32got_32trolled_32level_325Code.eventsList0(runtimeScene);
gdjs.you_32got_32trolled_32level_325Code.GDDinoDouxObjects1.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDDinoDouxObjects2.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDGreenLeaves2Objects1.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDGreenLeaves2Objects2.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDBlueSmallPlantObjects1.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDBlueSmallPlantObjects2.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDNewTextObjects1.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDNewTextObjects2.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDPlayer_9595currencyObjects1.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDPlayer_9595currencyObjects2.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDGreenLeaves2Objects1.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDGreenLeaves2Objects2.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDDinoDoux2Objects1.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDDinoDoux2Objects2.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDOrangeLeaves3Objects1.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDOrangeLeaves3Objects2.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDGreenBush7Objects1.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDGreenBush7Objects2.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDGreenBush8Objects1.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDGreenBush8Objects2.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDBlueSmallPlant2Objects1.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDBlueSmallPlant2Objects2.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDBlueFlower2Objects1.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDBlueFlower2Objects2.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDRock3Objects1.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDRock3Objects2.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDCircleObjects1.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDCircleObjects2.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDLineLightJoystickObjects1.length = 0;
gdjs.you_32got_32trolled_32level_325Code.GDLineLightJoystickObjects2.length = 0;


return;

}

gdjs['you_32got_32trolled_32level_325Code'] = gdjs.you_32got_32trolled_32level_325Code;
