gdjs.shop_32type_32shhCode = {};
gdjs.shop_32type_32shhCode.localVariables = [];
gdjs.shop_32type_32shhCode.GDTransparentButtonWithWhiteYellowBorderObjects1= [];
gdjs.shop_32type_32shhCode.GDTransparentButtonWithWhiteYellowBorderObjects2= [];
gdjs.shop_32type_32shhCode.GDDinoVitaObjects1= [];
gdjs.shop_32type_32shhCode.GDDinoVitaObjects2= [];
gdjs.shop_32type_32shhCode.GDDinoLenaObjects1= [];
gdjs.shop_32type_32shhCode.GDDinoLenaObjects2= [];
gdjs.shop_32type_32shhCode.GDDinoMortObjects1= [];
gdjs.shop_32type_32shhCode.GDDinoMortObjects2= [];
gdjs.shop_32type_32shhCode.GDDinoShadowObjects1= [];
gdjs.shop_32type_32shhCode.GDDinoShadowObjects2= [];
gdjs.shop_32type_32shhCode.GDDinoDouxObjects1= [];
gdjs.shop_32type_32shhCode.GDDinoDouxObjects2= [];
gdjs.shop_32type_32shhCode.GDMedievalButtonBeigeObjects1= [];
gdjs.shop_32type_32shhCode.GDMedievalButtonBeigeObjects2= [];
gdjs.shop_32type_32shhCode.GDOrangeButtonWithStoneFrameObjects1= [];
gdjs.shop_32type_32shhCode.GDOrangeButtonWithStoneFrameObjects2= [];
gdjs.shop_32type_32shhCode.GDRedButtonWithStoneFrameObjects1= [];
gdjs.shop_32type_32shhCode.GDRedButtonWithStoneFrameObjects2= [];
gdjs.shop_32type_32shhCode.GDNewTextObjects1= [];
gdjs.shop_32type_32shhCode.GDNewTextObjects2= [];
gdjs.shop_32type_32shhCode.GDPlayer_9595currencyObjects1= [];
gdjs.shop_32type_32shhCode.GDPlayer_9595currencyObjects2= [];
gdjs.shop_32type_32shhCode.GDGreenLeaves2Objects1= [];
gdjs.shop_32type_32shhCode.GDGreenLeaves2Objects2= [];
gdjs.shop_32type_32shhCode.GDDinoDoux2Objects1= [];
gdjs.shop_32type_32shhCode.GDDinoDoux2Objects2= [];
gdjs.shop_32type_32shhCode.GDOrangeLeaves3Objects1= [];
gdjs.shop_32type_32shhCode.GDOrangeLeaves3Objects2= [];
gdjs.shop_32type_32shhCode.GDGreenBush7Objects1= [];
gdjs.shop_32type_32shhCode.GDGreenBush7Objects2= [];
gdjs.shop_32type_32shhCode.GDGreenBush8Objects1= [];
gdjs.shop_32type_32shhCode.GDGreenBush8Objects2= [];
gdjs.shop_32type_32shhCode.GDBlueSmallPlant2Objects1= [];
gdjs.shop_32type_32shhCode.GDBlueSmallPlant2Objects2= [];
gdjs.shop_32type_32shhCode.GDBlueFlower2Objects1= [];
gdjs.shop_32type_32shhCode.GDBlueFlower2Objects2= [];
gdjs.shop_32type_32shhCode.GDRock3Objects1= [];
gdjs.shop_32type_32shhCode.GDRock3Objects2= [];
gdjs.shop_32type_32shhCode.GDCircleObjects1= [];
gdjs.shop_32type_32shhCode.GDCircleObjects2= [];
gdjs.shop_32type_32shhCode.GDLineLightJoystickObjects1= [];
gdjs.shop_32type_32shhCode.GDLineLightJoystickObjects2= [];


gdjs.shop_32type_32shhCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("TransparentButtonWithWhiteYellowBorder"), gdjs.shop_32type_32shhCode.GDTransparentButtonWithWhiteYellowBorderObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.shop_32type_32shhCode.GDTransparentButtonWithWhiteYellowBorderObjects1.length;i<l;++i) {
    if ( gdjs.shop_32type_32shhCode.GDTransparentButtonWithWhiteYellowBorderObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.shop_32type_32shhCode.GDTransparentButtonWithWhiteYellowBorderObjects1[k] = gdjs.shop_32type_32shhCode.GDTransparentButtonWithWhiteYellowBorderObjects1[i];
        ++k;
    }
}
gdjs.shop_32type_32shhCode.GDTransparentButtonWithWhiteYellowBorderObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main menu", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main menu", false);
}}

}


};

gdjs.shop_32type_32shhCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.shop_32type_32shhCode.GDTransparentButtonWithWhiteYellowBorderObjects1.length = 0;
gdjs.shop_32type_32shhCode.GDTransparentButtonWithWhiteYellowBorderObjects2.length = 0;
gdjs.shop_32type_32shhCode.GDDinoVitaObjects1.length = 0;
gdjs.shop_32type_32shhCode.GDDinoVitaObjects2.length = 0;
gdjs.shop_32type_32shhCode.GDDinoLenaObjects1.length = 0;
gdjs.shop_32type_32shhCode.GDDinoLenaObjects2.length = 0;
gdjs.shop_32type_32shhCode.GDDinoMortObjects1.length = 0;
gdjs.shop_32type_32shhCode.GDDinoMortObjects2.length = 0;
gdjs.shop_32type_32shhCode.GDDinoShadowObjects1.length = 0;
gdjs.shop_32type_32shhCode.GDDinoShadowObjects2.length = 0;
gdjs.shop_32type_32shhCode.GDDinoDouxObjects1.length = 0;
gdjs.shop_32type_32shhCode.GDDinoDouxObjects2.length = 0;
gdjs.shop_32type_32shhCode.GDMedievalButtonBeigeObjects1.length = 0;
gdjs.shop_32type_32shhCode.GDMedievalButtonBeigeObjects2.length = 0;
gdjs.shop_32type_32shhCode.GDOrangeButtonWithStoneFrameObjects1.length = 0;
gdjs.shop_32type_32shhCode.GDOrangeButtonWithStoneFrameObjects2.length = 0;
gdjs.shop_32type_32shhCode.GDRedButtonWithStoneFrameObjects1.length = 0;
gdjs.shop_32type_32shhCode.GDRedButtonWithStoneFrameObjects2.length = 0;
gdjs.shop_32type_32shhCode.GDNewTextObjects1.length = 0;
gdjs.shop_32type_32shhCode.GDNewTextObjects2.length = 0;
gdjs.shop_32type_32shhCode.GDPlayer_9595currencyObjects1.length = 0;
gdjs.shop_32type_32shhCode.GDPlayer_9595currencyObjects2.length = 0;
gdjs.shop_32type_32shhCode.GDGreenLeaves2Objects1.length = 0;
gdjs.shop_32type_32shhCode.GDGreenLeaves2Objects2.length = 0;
gdjs.shop_32type_32shhCode.GDDinoDoux2Objects1.length = 0;
gdjs.shop_32type_32shhCode.GDDinoDoux2Objects2.length = 0;
gdjs.shop_32type_32shhCode.GDOrangeLeaves3Objects1.length = 0;
gdjs.shop_32type_32shhCode.GDOrangeLeaves3Objects2.length = 0;
gdjs.shop_32type_32shhCode.GDGreenBush7Objects1.length = 0;
gdjs.shop_32type_32shhCode.GDGreenBush7Objects2.length = 0;
gdjs.shop_32type_32shhCode.GDGreenBush8Objects1.length = 0;
gdjs.shop_32type_32shhCode.GDGreenBush8Objects2.length = 0;
gdjs.shop_32type_32shhCode.GDBlueSmallPlant2Objects1.length = 0;
gdjs.shop_32type_32shhCode.GDBlueSmallPlant2Objects2.length = 0;
gdjs.shop_32type_32shhCode.GDBlueFlower2Objects1.length = 0;
gdjs.shop_32type_32shhCode.GDBlueFlower2Objects2.length = 0;
gdjs.shop_32type_32shhCode.GDRock3Objects1.length = 0;
gdjs.shop_32type_32shhCode.GDRock3Objects2.length = 0;
gdjs.shop_32type_32shhCode.GDCircleObjects1.length = 0;
gdjs.shop_32type_32shhCode.GDCircleObjects2.length = 0;
gdjs.shop_32type_32shhCode.GDLineLightJoystickObjects1.length = 0;
gdjs.shop_32type_32shhCode.GDLineLightJoystickObjects2.length = 0;

gdjs.shop_32type_32shhCode.eventsList0(runtimeScene);
gdjs.shop_32type_32shhCode.GDTransparentButtonWithWhiteYellowBorderObjects1.length = 0;
gdjs.shop_32type_32shhCode.GDTransparentButtonWithWhiteYellowBorderObjects2.length = 0;
gdjs.shop_32type_32shhCode.GDDinoVitaObjects1.length = 0;
gdjs.shop_32type_32shhCode.GDDinoVitaObjects2.length = 0;
gdjs.shop_32type_32shhCode.GDDinoLenaObjects1.length = 0;
gdjs.shop_32type_32shhCode.GDDinoLenaObjects2.length = 0;
gdjs.shop_32type_32shhCode.GDDinoMortObjects1.length = 0;
gdjs.shop_32type_32shhCode.GDDinoMortObjects2.length = 0;
gdjs.shop_32type_32shhCode.GDDinoShadowObjects1.length = 0;
gdjs.shop_32type_32shhCode.GDDinoShadowObjects2.length = 0;
gdjs.shop_32type_32shhCode.GDDinoDouxObjects1.length = 0;
gdjs.shop_32type_32shhCode.GDDinoDouxObjects2.length = 0;
gdjs.shop_32type_32shhCode.GDMedievalButtonBeigeObjects1.length = 0;
gdjs.shop_32type_32shhCode.GDMedievalButtonBeigeObjects2.length = 0;
gdjs.shop_32type_32shhCode.GDOrangeButtonWithStoneFrameObjects1.length = 0;
gdjs.shop_32type_32shhCode.GDOrangeButtonWithStoneFrameObjects2.length = 0;
gdjs.shop_32type_32shhCode.GDRedButtonWithStoneFrameObjects1.length = 0;
gdjs.shop_32type_32shhCode.GDRedButtonWithStoneFrameObjects2.length = 0;
gdjs.shop_32type_32shhCode.GDNewTextObjects1.length = 0;
gdjs.shop_32type_32shhCode.GDNewTextObjects2.length = 0;
gdjs.shop_32type_32shhCode.GDPlayer_9595currencyObjects1.length = 0;
gdjs.shop_32type_32shhCode.GDPlayer_9595currencyObjects2.length = 0;
gdjs.shop_32type_32shhCode.GDGreenLeaves2Objects1.length = 0;
gdjs.shop_32type_32shhCode.GDGreenLeaves2Objects2.length = 0;
gdjs.shop_32type_32shhCode.GDDinoDoux2Objects1.length = 0;
gdjs.shop_32type_32shhCode.GDDinoDoux2Objects2.length = 0;
gdjs.shop_32type_32shhCode.GDOrangeLeaves3Objects1.length = 0;
gdjs.shop_32type_32shhCode.GDOrangeLeaves3Objects2.length = 0;
gdjs.shop_32type_32shhCode.GDGreenBush7Objects1.length = 0;
gdjs.shop_32type_32shhCode.GDGreenBush7Objects2.length = 0;
gdjs.shop_32type_32shhCode.GDGreenBush8Objects1.length = 0;
gdjs.shop_32type_32shhCode.GDGreenBush8Objects2.length = 0;
gdjs.shop_32type_32shhCode.GDBlueSmallPlant2Objects1.length = 0;
gdjs.shop_32type_32shhCode.GDBlueSmallPlant2Objects2.length = 0;
gdjs.shop_32type_32shhCode.GDBlueFlower2Objects1.length = 0;
gdjs.shop_32type_32shhCode.GDBlueFlower2Objects2.length = 0;
gdjs.shop_32type_32shhCode.GDRock3Objects1.length = 0;
gdjs.shop_32type_32shhCode.GDRock3Objects2.length = 0;
gdjs.shop_32type_32shhCode.GDCircleObjects1.length = 0;
gdjs.shop_32type_32shhCode.GDCircleObjects2.length = 0;
gdjs.shop_32type_32shhCode.GDLineLightJoystickObjects1.length = 0;
gdjs.shop_32type_32shhCode.GDLineLightJoystickObjects2.length = 0;


return;

}

gdjs['shop_32type_32shhCode'] = gdjs.shop_32type_32shhCode;
